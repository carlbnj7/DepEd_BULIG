<?php
/** Display-only labels and reviewed picture mappings; no database writes. */
function lesson_display_label(int $level,int $position):string{
 if($level===5)return $position===1?'Pre-test':($position>=100?'Post-test':'Passage '.($position-1));
 if(in_array($level,[2,3,4],true)){
  $lessons=module_source_meta($level)['lessons']??[];
  foreach($lessons as $lesson)if((int)$lesson['position']===$position){
   if($lesson['phase']==='pre')return 'Pre-assessment';
   if($lesson['phase']==='post')return 'Post-assessment';
   $number=0;foreach($lessons as $item)if($item['phase']==='learn'&&(int)$item['position']<=$position)$number++;
   return 'Lesson '.$number;
  }
 }
 return 'Lesson '.$position;
}
function lesson_count_label(int $level,int $total):string{
 if($level===5&&$total>2)return ($total-2).' passages + pre/post tests';
 return in_array($level,[2,3,4],true)&&$total>2?($total-2).' lessons + pre/post assessments':$total.' lessons';
}
function level1_visual_manifest():array{
 static $m=null;if($m===null){$f=__DIR__.'/../database/level1-visuals-v11.json';$m=is_file($f)?json_decode(file_get_contents($f),true):[];}return $m??[];
}
function level1_visual_override(array $a):?array{
 $m=level1_visual_manifest()['activities'][(string)($a['id']??0)]??null;
 if(!$m||(int)($a['lesson_id']??0)!==(int)$m['lesson_id']||(int)($a['revision']??1)>1)return null;
 // Do not attach a stock picture to changed/custom text.
 if(!hash_equals($m['prompt_sha256'],hash('sha256',(string)($a['prompt']??''))))return null;
 return $m;
}
/** Level 3 reading lists shown as a table of word boxes, like the printed module. */
function level3_reading_grid(array $a):?string{
 if(($a['type']??'')!=='reading'||lesson_level((int)($a['lesson_id']??0))!==4)return null;
 $prompt=trim(str_replace(["\r\n","\r"],"\n",(string)$a['prompt']));
 if(str_contains($prompt,"\n"))$items=array_values(array_filter(array_map('trim',explode("\n",$prompt)),'strlen'));
 else $items=preg_split('/\s{2,}/',$prompt,-1,PREG_SPLIT_NO_EMPTY);
 if(count($items)<2)return null;
 $long=max(array_map(fn($w)=>mb_strlen($w),$items))>14;
 $html='<div class="word-grid'.($long?' word-grid-lines':'').'" role="list">';
 foreach($items as $w)$html.='<span class="word-box" role="listitem">'.e($w).'</span>';
 return $html.'</div>';
}
/** Level 4 fluency passage: "Title:", "Author:" and "Words:" header lines, a blank line, then the text (blank lines between paragraphs or stanzas). */
function level4_passage_parts(array $a):?array{
 if(($a['type']??'')!=='reading'||lesson_level((int)($a['lesson_id']??0))!==5)return null;
 $text=str_replace("\r\n","\n",(string)$a['prompt']);$head=[];
 while(preg_match('/^(Title|Author|Words):[ \t]*(.*)\n/',$text,$m)){$head[strtolower($m[1])]=trim($m[2]);$text=substr($text,strlen($m[0]));}
 $blocks=array_values(array_filter(array_map('trim',preg_split("/\n\s*\n/",$text)),'strlen'));
 $words=(int)($head['words']??0)?:count(preg_split('/\s+/',trim(implode(' ',$blocks))));
 return ['title'=>$head['title']??'','author'=>$head['author']??'','words'=>$words,'blocks'=>$blocks];
}
function level4_passage(array $a,bool $pictures=true):?string{
 $p=level4_passage_parts($a);if(!$p)return null;
 $verse=count(array_filter($p['blocks'],fn($b)=>str_contains($b,"\n")))>0;
 $h='<article class="fluency-passage'.($verse?' is-verse':'').'" data-words="'.$p['words'].'">';
 if($pictures){$imgs=activity_images($a);if($imgs){$h.='<div class="fluency-pictures">';foreach($imgs as $i)$h.='<img src="'.e($i).'" alt="Picture from the module for this passage" loading="lazy">';$h.='</div>';}}
 $h.='<h2 class="fluency-title">'.e($p['title']).'</h2>'.($p['author']!==''?'<p class="fluency-author">'.e($p['author']).'</p>':'').'<div class="fluency-text">';
 foreach($p['blocks'] as $b)$h.='<p>'.nl2br(e($b),false).'</p>';
 return $h.'</div><p class="fluency-count">Number of words in the passage: <strong>'.$p['words'].'</strong></p></article>';
}
