/* BULIG service worker: lets the app be installed, shows a friendly page when offline,
   opens levels a pupil saved for offline use (caches named bulig-off-<pupil>-L<level>),
   and keeps the sign-in page (cache bulig-login) so saved accounts can open their lessons offline.
   Teachers' saved Class Demo levels use the same caches (bulig-off-<teacher>-D<level>). */
const CACHE='bulig-offline-v15';
const FILES=['offline.html','assets/offline.css','assets/brand/bulig-tab.png','assets/brand/bulig-app-medium.png','assets/bulig-logo.png','assets/brand/bulig-gamified.webp','assets/brand/bulig-gamified-mark.webp','assets/fonts/poppins-latin-600-normal.woff2'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE&&k!==FRESH&&!k.startsWith('bulig-off-')&&k!=='bulig-who'&&k!=='bulig-login').map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});

/* The Level 2A, 2B, 3, 4, 5, 6 and 7 pictures were redrawn but kept their file names. Browsers keep pictures for up to 7 days,
   so each one is fetched fresh from BULIG once (cache "bulig-fresh-3" remembers which; a new name when more pictures are redrawn), then used normally. */
const FRESH='bulig-fresh-3';
async function freshOnce(r){const c=await caches.open(FRESH),k=new URL(r.url);k.search='';
 if(await c.match(k.href))return fetch(r);
 const res=await fetch(r.url,{cache:'reload',credentials:'same-origin'});if(res.ok)await c.put(k.href,new Response(''));return res;}

/* The pupil using BULIG on this device; saved pages are only shown to that pupil. */
async function who(){try{const c=await caches.open('bulig-who');const r=await c.match('who');return r?(await r.text()):'';}catch(e){return '';}}
async function saved(req,onlyPage){
 const uid=await who();if(onlyPage&&!uid)return null;
 const names=(await caches.keys()).filter(k=>k.startsWith('bulig-off-')&&(!onlyPage||k.startsWith('bulig-off-'+uid+'-')));
 if(!onlyPage)names.push('bulig-login');
 const u=new URL(req.url);
 /* The installed app opens "?page=dashboard&source=app"; the opening page may have no "page" at all. */
 u.searchParams.delete('source');if(onlyPage&&!u.searchParams.get('page'))u.searchParams.set('page','dashboard');
 const tries=[u.href];
 if(onlyPage&&u.searchParams.has('feedback')){u.searchParams.delete('feedback');tries.push(u.href);}
 /* Class Demo keeps the slide in the address (activity, card, lesson); the saved copy is the whole level. */
 if(onlyPage&&u.searchParams.get('page')==='class_demo'&&['activity','card','lesson'].some(k=>u.searchParams.has(k))){['activity','card','lesson'].forEach(k=>u.searchParams.delete(k));tries.push(u.href);}
 for(const t of tries)for(const n of names){const r=await (await caches.open(n)).match(t);if(r)return r;}
 return null;
}
async function loginPage(req){try{const c=await caches.open('bulig-login');return await c.match(new URL('?page=login',req.url).href);}catch(e){return null;}}
async function offlinePage(req){
 const page=new URL(req.url).searchParams.get('page')||'';
 if(page!=='login'){const s=await saved(req,true);if(s)return s;}
 /* Signed out, or the sign-in page itself: show the saved sign-in page so a saved pupil can tap their picture. */
 if(page==='login'||!(await who())){const l=await loginPage(req);if(l)return l;}
 return caches.match('offline.html');
}
self.addEventListener('fetch',e=>{
 const r=e.request;
 if(r.method!=='GET'||new URL(r.url).origin!==location.origin)return;
 const url=new URL(r.url);
 if(['offline_sync','offline_manifest','offline_levels','demo_offline'].includes(url.searchParams.get('page'))||url.searchParams.get('off')==='1')return;
 if(r.mode==='navigate'){e.respondWith(fetch(r).catch(()=>offlinePage(r)));return;}
 if(FILES.some(f=>url.pathname.endsWith('/'+f))){e.respondWith(fetch(r).catch(()=>caches.match(r,{ignoreSearch:true})));return;}
 if(/\/assets\/images\/level(2[ab]|[3-7])\/([^/]+\/)?[^/]+\.webp$/.test(url.pathname)){e.respondWith(freshOnce(r).catch(async()=>(await saved(r,false))||Response.error()));return;}
 if(/\.(css|js|png|jpe?g|webp|gif|svg|woff2?|ico)$/i.test(url.pathname))e.respondWith(fetch(r).catch(async()=>(await saved(r,false))||Response.error()));
});

/* Reminders (Web Push): show the note, and open BULIG at the right page when it is tapped. */
self.addEventListener('push',e=>{let d={};try{d=e.data?e.data.json():{};}catch(x){d={body:e.data?e.data.text():''};}
 e.waitUntil(self.registration.showNotification(d.title||'BULIG',{body:d.body||'',icon:d.icon||'assets/brand/bulig-app-medium.png?v=9',badge:'assets/brand/bulig-tab-big.png?v=9',tag:d.tag||'bulig',data:{url:d.url||'?page=dashboard'}}));});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=new URL((e.notification.data&&e.notification.data.url)||'?page=dashboard',self.registration.scope).href;
 e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{for(const c of list){if(c.url.startsWith(self.registration.scope)&&'focus' in c){if('navigate' in c)c.navigate(url).catch(()=>{});return c.focus();}}return clients.openWindow(url);}));});

