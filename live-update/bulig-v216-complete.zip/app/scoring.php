<?php
/* Auto-checking for every level.
   - database/answer-keys.json (Levels 5-7, the module answer keys checked against the stories) is built from
     database/keys/*.txt by tools/keys/build.php. Where the module's own key is wrong, the right answer is used and the
     card is marked "fix".
   - database/answer-keys-2.json (Levels 2A, 2B and 3, and the Level 5-7 cards the module key left out) is built from
     database/keys2/*.txt by tools/keys/build2.php. The modules have no key for these, so BULIG judged each answer from
     the pictures, the words and the stories.
   - A card with a key is right or wrong (a matching board scores 1 point per pair, numbering events 1 point per event).
   - A card without a single right answer (speaking, drawing, writing your own ideas, reading aloud) counts as right
     when the pupil answers it. Level 1 is spoken: an answered activity counts as right.
   - The teacher can always change the score. Level 4 readings are scored by BULIG with the module's miscue table
     (app/level4.php: l4_auto), or by the teacher when the device could not listen. */

function answer_keys():array{static $k;if($k===null){$k=['keys'=>[],'notes'=>[]];
 foreach(['answer-keys.json','answer-keys-2.json','answer-keys-jhs.json'] as $f){$f=__DIR__.'/../database/'.$f;$j=is_file($f)?(json_decode((string)file_get_contents($f),true)??[]):[];
  foreach($j['keys']??[] as $id=>$cards)foreach($cards as $n=>$c)$k['keys'][$id][$n]=$c;foreach($j['notes']??[] as $id=>$x)$k['notes'][$id]=array_merge($k['notes'][$id]??[],$x);}
 /* v206: the drawing cards became picture cards (database/draw-picks.json): their right pictures */
 if(function_exists('draw_picks'))foreach(draw_picks() as $ref=>$c){if(empty($c['key']))continue;[$id,$n]=explode('|',$ref);$kk=$c['key'];
  if(isset($kk['eq'])){$k['keys'][$id][(int)$n]=['t'=>'card','alts'=>[[['k'=>'eq','v'=>key_norm((string)$kk['eq'])]]],'w'=>(string)$kk['eq']];continue;}
  $k['keys'][$id][(int)$n]=['t'=>'card','alts'=>[[['k'=>'set','req'=>$kk['req'],'opt'=>$kk['opt'],'min'=>$kk['min'],'pics'=>1]]],'w'=>implode(', ',array_map(fn($i)=>'Picture '.$i.(($c['images'][$i-1]['say']??'')!==''?' ('.$c['images'][$i-1]['say'].')':''),array_merge($kk['req'],$kk['opt'])))];}
 }return $k;}

/** The key of one activity ("level:grade:lesson position:phase:position", grade 0 for levels shared by every grade). */
function activity_key_id(array $a):?string{
 static $c=[];$id=(int)$a['id'];if(array_key_exists($id,$c))return $c[$id];
 $r=one('SELECT a.phase,a.position,l.position lpos,IFNULL(m.grade_level,0) g,m.level_id lv FROM activities a JOIN lessons l ON l.id=a.lesson_id JOIN modules m ON m.id=l.module_id WHERE a.id=?',[$id]);
 return $c[$id]=$r?level_family((int)$r['lv']).':'.$r['g'].':'.$r['lpos'].':'.$r['phase'].':'.$r['position']:null;
}
function activity_key(array $a):?array{if(!isset($a['lesson_id']))$a=one('SELECT * FROM activities WHERE id=?',[(int)$a['id']])??$a;$id=activity_key_id($a);$keys=$id?(answer_keys()['keys'][$id]??[]):[];if(isset($a['lesson_id'])&&function_exists('module_activity_keys'))$keys=module_activity_keys($a,$keys);return $keys?:null;}

/** The pupil's answer for each card, from "BULIG card answers / Card n (no. t): ...". */
function card_answers(string $response):array{
 $r=card_strip_tries(str_replace(["\r\n","\r"],"\n",$response));$out=[];if(!str_starts_with($r,"BULIG card answers\n"))return $out;
 foreach(preg_split('/\n(?=Card [0-9]+(?: \(no\. [0-9]+\))?:)/',substr($r,19)) as $line)if(preg_match('/^Card ([0-9]+)(?: \(no\. [0-9]+\))?:\s?(.*)$/s',$line,$m))$out[(int)$m[1]]=trim($m[2]);
 return $out;
}
function key_norm(string $s):string{return mb_strtolower(trim(preg_replace('~\s+~u',' ',str_replace(['’','‘','“','”'],["'","'",'"','"'],$s))));}
/** Letters and numbers only: "/m/ /a/ /t/" and "m a t" both give "mat". */
function key_letters(string $s):string{return preg_replace('~[^\p{L}\p{N}\']+~u','',mb_strtolower(str_replace(['’','‘'],"'",$s)));}

/** One part of a judged card (answer-keys-2.json) against one piece of the pupil's answer. */
function key_part_ok(array $k,string $g):bool{
 switch($k['k']){
  case 'any':return true;
  case 'eq':return $g!==''&&(key_norm($g)===$k['v']||key_letters($g)===$k['v']);
  case 'has':$t=key_letters($g);$n=0;foreach($k['v'] as $w)if($w!==''&&str_contains($t,$w))$n++;return $t!==''&&$n>=$k['n'];
  case 'build':return $g!==''&&key_letters(preg_replace('~\s*\(tries:.*$~u','',$g))===$k['v']&&!str_starts_with($g,'tries:');
  case 'onset':return str_replace(' ','',mb_strtolower($g))===$k['v'];
  case 'syl':$p=array_filter(array_map('trim',explode('/',mb_strtolower($g))),'strlen');if(count($p)!==$k['n']||substr_count($g,'/')!==$k['n']-1)return false;foreach($p as $x)if(!preg_match('~[aeiouy]~u',$x))return false;return true;
  case 'pairs':if(!preg_match_all('~(\d+)\s*[–-]\s*(\d+)~u',$g,$mm,PREG_SET_ORDER))return false;$have=[];foreach($mm as $m){$x=[(int)$m[1],(int)$m[2]];sort($x);$have[]=implode('-',$x);}$want=array_map(fn($x)=>implode('-',$x),$k['v']);sort($have);sort($want);return $have===$want;
  case 'set':
   if(!empty($k['pics'])){preg_match_all('~Picture (\d+)~',$g,$mm);$have=array_map('intval',$mm[1]);}else $have=array_map('key_norm',array_filter(array_map('trim',explode(',',$g)),'strlen'));
   if(!$have)return false;$allowed=array_merge($k['req'],$k['opt']);foreach($have as $x)if(!in_array($x,$allowed,true))return false;
   if(!empty($k['min']))return count(array_unique($have))>=$k['min'];foreach($k['req'] as $x)if(!in_array($x,$have,true))return false;return true;
 }
 return false;
}
/** A judged card: right when one of its answers fits every part (a part matches any piece of a multi-part answer). */
function key_card_ok(array $k,string $g):bool{
 $pieces=$g===''?[]:explode(' · ',$g);
 foreach($k['alts'] as $alt){$all=true;
  if(count($alt)===1){if(!key_part_ok($alt[0],$g))$all=false;}
  else foreach($alt as $part){if($part['k']==='any')continue;$hit=false;foreach($pieces as $pc)if(key_part_ok($part,trim($pc))){$hit=true;break;}if(!$hit){$all=false;break;}}
  if($all)return true;}
 return false;
}
/** The right answer to show the teacher. */
function key_want(array $k):string{
 if($k['t']==='card')return (string)$k['w'];
 if($k['t']==='choice')return implode(' or ',array_merge([$k['a']],$k['alt']??[]));
 if($k['t']==='match')return implode(', ',array_map(fn($i,$l)=>$i.'-'.$l,array_keys($k['a']),$k['a']));
 return implode(' · ',array_map(fn($l,$v)=>$l.' = '.$v,array_keys($k['a']),$k['a']));
}
/** True when the pupil gave an answer to a card (spoken, drawn, written or tapped). */
function key_answered(string $g):bool{return $g!==''&&$g!=='(seen)';}

/** Points for one card: [points, out of, the right answer, key type]. A card without a key counts as right when answered. */
function key_card_points(?array $k,string $g):array{
 $pts=0;$of=1;$want='';$t=$k['t']??'open';
 if(!$k){$pts=key_answered($g)?1:0;$want='Any answer';}
 elseif($t==='card'){$pts=key_card_ok($k,$g)?1:0;$want=key_want($k);}
 elseif($t==='choice'){$ok=array_merge([$k['a']],$k['alt']??[]);$want=key_want($k);$pts=$g!==''&&in_array(key_norm($g),array_map('key_norm',$ok),true)?1:0;}
 elseif($t==='match'){$of=count($k['a']);$have=[];if(preg_match_all('~(\d+)\s*-\s*([a-z])~i',$g,$mm,PREG_SET_ORDER))foreach($mm as $m)$have[$m[1]]=strtolower($m[2]);
  foreach($k['a'] as $i=>$l)if(($have[(string)$i]??'')===$l)$pts++;$want=key_want($k);}
 elseif($t==='order'){$of=count($k['a']);$have=[];foreach(explode(' · ',$g) as $part)if(($p=strrpos($part,' = '))!==false)$have[key_norm(substr($part,0,$p))]=trim(substr($part,$p+3));
  foreach($k['a'] as $lab=>$num)if(($have[key_norm((string)$lab)]??'')===(string)$num)$pts++;$want=implode(' · ',array_map(fn($l,$v)=>$v,array_keys($k['a']),$k['a']));}
 return [$pts,$of,$want,$t];
}

/* Pronunciation check (v172). On a "say it" card BULIG listens while the pupil records (the browser's speech
   recognition) and the answer becomes "(voice recording) said: …". When the card shows what to say (a word list or a
   sentence to read, or a blend "/p/ /e/ /n/ → pen"), the card's point is the share of those words BULIG heard said
   right. Single sounds and open answers cannot be checked this way: they count when answered. When the device could
   not listen (no "said:"), the recording counts, so a phone without speech recognition never lowers a score. */
function say_expected(array $cd,string $dir):array{
 if(!in_array('say',$cd['ui']['answer']??[],true))return [];$t=trim(preg_replace('~\s+~u',' ',(string)($cd['text']??'')));if($t==='')return [];
 if(preg_match('~→\s*([\p{L}\']+)~u',$t,$m))return [key_letters($m[1])];
 if(empty($cd['ui']['max'])&&!preg_match('~\bread\b|review the words~i',$dir)&&!(trim($dir)===''&&!str_contains($t,'?')))return [];
 if(($i=mb_strrpos($t,':'))!==false)$t=mb_substr($t,$i+1);if(preg_match('~/[a-z]+/~i',$t))return [];/* sounds, not words */
 $w=array_values(array_filter(array_map('key_letters',preg_split('~[\s,;.!?"“”()]+~u',$t)),'strlen'));
 return count($w)>=1&&count($w)<=400?$w:[];
}
/** Picture cards ("say the word for the picture"): the words, from database/say-words.json ("a|b": either is right). */
function say_words():array{static $w;if($w===null){$f=__DIR__.'/../database/say-words.json';$w=is_file($f)?((json_decode((string)file_get_contents($f),true)['words'])??[]):[];}return $w;}
/** What BULIG heard on a recorded answer, or null when the device did not listen. */
function key_said(string $g):?string{return preg_match('~\)\s*said:\s*(.+)$~su',$g,$m)?trim($m[1]):null;}
/** Share of the expected words heard (each heard word counts once), 0 to 1. */
function say_num_words(string $w):string{static $n=['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty'];return preg_match('~^\d+$~',$w)&&(int)$w<count($n)?$n[(int)$w]:$w;}
/** v207: how a word sounds: "then" = "den", "wet" = "wed", "10" = "ten" (the vowel stays, so bed and bad differ) */
function say_sound(string $w):string{$w=say_num_words($w);
 $w=preg_replace(['~^th~','~th~','~^wh~','~ph~','~ck~','~c(?=[aou]|$)~','~q~','~x~','~(.)\1+~','~([^aeiou])e$~','~[dt]$~','~[gk]$~','~[bp]$~','~[sz]$~'],['d','d','w','f','k','k','k','ks','$1','$1','T','K','P','S'],$w)??$w;return $w;}
function say_match(array $exp,string $heard):float{
 if(!$exp)return 1.0;
 /* v208 speech setting (app/reading_support.php): Speech support is never marked wrong (the teacher listens); Accent-friendly compares accent keys */
 $sm=function_exists('speech_me')?speech_me():'standard';if($sm==='support')return 1.0;$key=$sm==='accent'?fn($x)=>accent_key(key_letters($x)):fn($x)=>say_sound(key_letters($x));
 $h=array_count_values(array_filter(array_map($key,preg_split('~\s+~u',$heard)),'strlen'));$ok=0;
 foreach($exp as $w)foreach(explode('|',$w) as $alt){$alt=$key($alt);if(($h[$alt]??0)>0){$h[$alt]--;$ok++;break;}}
 return round($ok/count($exp),2);
}
/** Level 1 (oral) answers, checked by BULIG (v172): 0 to 1. With the words to say (expected_text): the share BULIG heard
    said right. Otherwise how much the pupil said: 3 or more words 1, 1-2 words 0.8 (2 stars). A recording the device could not
    listen to, or an answer said aloud in class, counts as 1. */
function l1_auto_score(array $a,string $transcript,bool $recorded):float{
 $said=trim($transcript);if(function_exists('speech_me')&&speech_me()==='support')return 1.0;   // v208 Speech support: the teacher listens
 if($said!==''&&trim((string)($a['expected_text']??''))!==''){$exp=array_values(array_filter(array_map('key_letters',preg_split('~\s+~u',(string)$a['expected_text'])),'strlen'));return say_match($exp,$said);}
 if($said!==''){$n=count(array_filter(preg_split('~\s+~u',$said),'strlen'));return $n>=3?1.0:0.8;}   // v181: a short answer is still an answer (2 stars), so it never blocks a young pupil
 return 1.0;
}

/* Wrong tries (v172). In lessons BULIG checks each card right away (action card_check) and the pupil may try again as
   many times as they like. Each wrong try takes away a third of the card's points (after KEY_TRIES wrong tries the card
   is worth 0, but the pupil can still finish it). The tries are kept as a last line of the answer, "Tries: 2=1, 5=4"
   (card = wrong tries); the server counts them too and keeps the higher number. Pre-tests and post-tests are not
   checked card by card. */
const KEY_TRIES=3;
function card_tries(string $response):array{
 if(!preg_match('/\nTries: ([0-9=, ]*)\s*$/',$response,$m))return [];$t=[];
 foreach(explode(',',$m[1]) as $p)if(preg_match('/^\s*(\d+)=(\d+)\s*$/',$p,$x))$t[(int)$x[1]]=min(999,(int)$x[2]);return $t;
}
function card_strip_tries(string $r):string{return preg_replace('/\nTries: [0-9=, ]*\s*$/','',preg_replace('/\nCoach: [^\n]*/u','',$r));}   // v184: the Word Coach line too
function card_tries_line(array $t):string{$t=array_filter($t);ksort($t);return $t?"\nTries: ".implode(', ',array_map(fn($n,$v)=>$n.'='.$v,array_keys($t),$t)):'';}
/** At "Done": add the tries BULIG counted on this device's session (the higher count wins). */
function key_merge_tries(string $answer,int $aid):string{
 $mine=$_SESSION['ck'][$aid]??[];unset($_SESSION['ck'][$aid]);if(!str_starts_with($answer,"BULIG card answers\n"))return $answer;
 $t=card_tries($answer);foreach($mine as $n=>$v)$t[(int)$n]=max($t[(int)$n]??0,min(999,(int)$v));
 return card_strip_tries($answer).card_tries_line($t);
}
/** True when card checking is on for this activity: a lesson activity (not a pre-test or post-test) with an answer key. */
function key_checks_cards(array $a):bool{return ($a['phase']??'learn')==='learn'&&function_exists('ac_keyed')&&ac_keyed($a);}
/** One card checked right away: ['keyed'=>, 'ok'=>, 'want'=>]. */
function key_check_card(array $a,int $n,string $g):array{
 $key=activity_key($a)??[];$k=$key[$n]??$key[(string)$n]??null;if(!$k)return ['keyed'=>false,'ok'=>true,'want'=>''];
 [$pts,$of,$want]=key_card_points($k,$g);return ['keyed'=>true,'ok'=>$pts>=$of,'want'=>$want,'pts'=>$pts,'of'=>$of];
}

/** Score one answer: ['right'=>, 'total'=>, 'cards'=>[n=>['got','want','pts','of','t','fix']]], or null for an activity
    with nothing to answer. Cards with a key are marked; every other card the pupil answers counts as right (t "open"). */
function key_score(array $a,string $response):?array{
 if(!isset($a['lesson_id']))$a=one('SELECT * FROM activities WHERE id=?',[(int)$a['id']])??$a;
 $lv=isset($a['lesson_id'])?lesson_level((int)$a['lesson_id']):0;$key=activity_key($a)??[];
 $set=in_array($lv,[2,3,4,9,6,7,8],true)?l2a_set($a):null;
 if(!$set){if(!$key)return in_array($a['response_mode']??'answer',['none','perform','drawing'],true)?null:['right'=>key_answered(trim($response))?1:0,'total'=>1,'cards'=>[]];$set=['cards'=>[]];}
 $got=card_answers($response);$right=0;$total=0;$cards=[];
 $ask=[];foreach($set['cards'] as $i=>$cd){$ui=$cd['ui']['answer']??[];if(array_diff($ui,['look','read'])||(in_array('read',$ui,true)&&key_answered(trim((string)($got[$i+1]??'')))))$ask[]=$i+1;}   // v185: a story read with the Reading Coach counts once it is read (older answers keep their score)
 $nums=array_values(array_unique(array_merge(array_map('intval',array_keys($key)),$ask)));sort($nums);
 $tries=card_tries($response);$wc=function_exists('card_coach')?card_coach($response):[];   // v184: Word Coach results
 $dir=(string)($set['instruction']??'');
 foreach($nums as $n){if(($got[$n]??'')==='(skipped)')continue;   // a page skipped with a bug report: not scored (v176)
  $k=$key[$n]??null;$g=(string)($got[$n]??'');[$pts,$of,$want,$t]=key_card_points($k,$g);
  if(!$k&&($exp=say_words()[activity_key_id($a).':'.$n]??say_expected($set['cards'][$n-1]??[],$dir))){$t='say';$want=implode(', ',array_map(fn($x)=>explode('|',$x)[0],$exp));$h=key_said($g);if($h!==null)$pts=say_match($exp,$h);}/* pronunciation (v172) */
  $ok=$pts>=$of;$tr=($k||$t==='say')?($tries[$n]??0):0;   // v185: a voice check's tries count too
  if($tr&&$of<=1)$pts=round($pts*max(0,1-$tr/KEY_TRIES),2);/* each wrong try takes away a third (v172); v209: not on a matching or ordering board, where Check says how many pairs are right and the pupil fixes the rest (the pairs right at the end are the score) */
  if(isset($wc[$n])&&$wc[$n]['p']!==null)$pts=round($of*$wc[$n]['p']/100,2);/* v184: the Word Coach run is the reading: its score counts */
  $right+=$pts;$total+=$of;$cards[$n]=['got'=>$g,'want'=>$want,'pts'=>$pts,'of'=>$of,'t'=>$t,'fix'=>!empty($k['fix']),'ok'=>$ok,'tries'=>$tr];}
 return $total?['right'=>$right,'total'=>$total,'cards'=>$cards]:null;
}

/** v183: "Done" activities (actions, games, pair work) and drawings have nothing to mark, so they count as done (no score).
    Before, they were saved as 0 of 1: 0 stars, and the pupil could not go on. This fixes saved answers once. */
function done_scores_repair():void{
 static $ran=false;if($ran)return;$ran=true;board_tries_repair();
 if(val("SELECT 1 FROM settings WHERE setting_key='fix_done_scores'"))return;
 foreach(rows("SELECT c.id,c.pupil_id,c.activity_id,c.status,c.response,c.rubric_scores,c.reviewed_by,a.phase FROM activity_completion c JOIN activities a ON a.id=c.activity_id WHERE a.response_mode IN ('perform','drawing') AND c.max_score=1 AND c.score=0") as $r){
  $j=json_decode((string)($r['rubric_scores']??''),true);if(is_array($j)&&isset($j['teacher_score']))continue;
  if(key_score(['id'=>(int)$r['activity_id']],(string)$r['response'])!==null)continue;
  q('UPDATE activity_completion SET score=NULL,max_score=NULL WHERE id=?',[(int)$r['id']]);
  if($r['status']==='retry'&&$r['phase']==='learn'&&$r['reviewed_by']===null){q("UPDATE activity_completion SET status='completed' WHERE id=?",[(int)$r['id']]);update_learning((int)$r['pupil_id'],(int)$r['activity_id']);}
 }
 q("INSERT INTO settings(setting_key,setting_value) VALUES('fix_done_scores','1') ON DUPLICATE KEY UPDATE setting_value='1'");
}

/** v209 (bug report #139): matching and ordering boards lost a third of their points for every Check with a pair still
    wrong, so 17 of 18 pairs right could end as 0%. Once: score those saved answers again (only when the score goes up),
    and a lesson activity that was sent back because of it counts as done. A score the teacher gave stays. */
function board_tries_repair():void{
 try{if(val("SELECT 1 FROM settings WHERE setting_key='fix_board_tries'"))return;
  foreach(rows("SELECT c.id,c.pupil_id,c.activity_id,c.status,c.score,c.max_score,c.reviewed_by,c.response,c.rubric_scores,a.phase FROM activity_completion c JOIN activities a ON a.id=c.activity_id WHERE c.response LIKE '%Tries: %' AND c.max_score IS NOT NULL") as $r){
   $j=json_decode((string)($r['rubric_scores']??''),true);if(is_array($j)&&(isset($j['teacher_score'])||isset($j['l4'])))continue;
   $key=activity_key(one('SELECT * FROM activities WHERE id=?',[(int)$r['activity_id']])??[])??[];$tr=card_tries((string)$r['response']);$hit=false;
   foreach($tr as $n=>$t)if($t&&in_array($key[$n]['t']??$key[(string)$n]['t']??'',['match','order'],true))$hit=true;if(!$hit)continue;
   $s=key_score(['id'=>(int)$r['activity_id']],(string)$r['response']);if(!$s||!$s['total']||$s['right']<=(float)$r['score']+1e-9)continue;
   q('UPDATE activity_completion SET score=?,max_score=? WHERE id=?',[$s['right'],$s['total'],(int)$r['id']]);
   if($r['status']==='retry'&&$r['phase']==='learn'&&$r['reviewed_by']===null&&round($s['right']/$s['total']*100,6)>=STAR_PASS){q("UPDATE activity_completion SET status='completed' WHERE id=?",[(int)$r['id']]);if(function_exists('update_learning'))update_learning((int)$r['pupil_id'],(int)$r['activity_id']);}
  }
  q("INSERT INTO settings(setting_key,setting_value) VALUES('fix_board_tries','1') ON DUPLICATE KEY UPDATE setting_value='1'");
 }catch(Throwable $e){}
}
/** Save the auto score on a completion (score / max_score), unless the teacher has already set one. */
function key_save_score(int $cid):void{
 $c=one('SELECT c.id,c.response,c.activity_id,c.reviewed_at,c.rubric_scores FROM activity_completion c WHERE c.id=?',[$cid]);if(!$c)return;
 $j=json_decode((string)($c['rubric_scores']??''),true);if(is_array($j)&&(isset($j['teacher_score'])||isset($j['l4'])))return;
 $s=key_score(['id'=>(int)$c['activity_id']],(string)$c['response']);if(!$s||!$s['total'])return;
 q('UPDATE activity_completion SET score=?,max_score=? WHERE id=?',[$s['right'],$s['total'],$cid]);
}

/** Teacher review: each marked card with the pupil's answer, a check or a cross, and the right answer. */
function key_review(array $r):string{
 $a=one('SELECT * FROM activities WHERE id=?',[(int)$r['activity_id']]);if(!$a)return '';$s=key_score($a,(string)$r['response']);if(!$s||!$s['cards'])return '';$set=l2a_set($a);$bc=$set?l2a_blank_counts($a,$set,lesson_level((int)$a['lesson_id'])):[];
 $open=count(array_filter($s['cards'],fn($c)=>$c['t']==='open'));
 $h='<div class="ks"><p class="ks-sum">'.l1_icon('ok').'<b>Auto score: '.$s['right'].' / '.$s['total'].'</b><span>'.($open?'Answers with one right answer are marked with the answer key. Spoken, drawn and written answers count when the pupil answered; change the score if you need to.':'Every answer is marked with the answer key.').'</span></p><ol class="ks-list">';
 foreach($s['cards'] as $n=>$c){$q=$set['cards'][$n-1]??[];$text=blank_plain(trim(preg_replace('~\s+~u',' ',(string)($q['text']??''))),$bc[$n-1]??0);if($text===''&&$c['t']==='match')$text='Matching';if($text===''&&$c['t']==='order')$text='Number the events';if($text===''&&($ch=array_values($q['ui']['opts'][0]??$q['choices']??[])))$text=implode(' / ',array_map('strval',$ch));if($text==='')$text=($q['images']??[])?'Picture card':'Card';
  $ok=$c['pts']===$c['of'];$h.='<li class="'.($ok?'ok':($c['pts']?'part':'no')).'"><span class="ks-q">Card '.$n.' · '.e(mb_strimwidth($text,0,110,'…')).'</span><span class="ks-a'.($c['t']==='open'&&mb_strlen($c['got'])>160?' ks-long':'').'">'.($c['got']!==''?($c['t']==='open'?nl2br(e($c['got'])):e(mb_strimwidth($c['got'],0,160,'…'))):'<i>No answer</i>').'</span><span class="ks-r">'.($ok?l1_icon('ok').($c['t']==='open'?'Answered':'Right'):($c['of']>1?$c['pts'].' / '.$c['of']:($c['t']==='open'?'No answer':'Wrong'))).(!$ok&&$c['t']!=='open'?' · Answer: '.e($c['want']):'').'</span></li>';}
 return $h.'</ol></div>';
}
function key_score_text(array $r):string{if($r['max_score']===null||(float)$r['max_score']<=0)return '';return rtrim(rtrim(number_format((float)$r['score'],2),'0'),'.').' / '.rtrim(rtrim(number_format((float)$r['max_score'],2),'0'),'.');}

/** True when every card a pupil answers is marked by the answer key: nothing written, drawn or recorded for the teacher to read. */
function key_fully_auto(int $aid):bool{
 static $c=[];if(isset($c[$aid]))return $c[$aid];$a=one('SELECT * FROM activities WHERE id=?',[$aid]);$key=$a?activity_key($a):null;$set=$key?l2a_set($a):null;if(!$set)return $c[$aid]=false;
 foreach($set['cards'] as $i=>$card){if(!array_diff($card['ui']['answer']??[],['look']))continue;if(!isset($key[$i+1]))return $c[$aid]=false;}
 return $c[$aid]=true;
}
/** Answers waiting for review that the answer key marked fully right, with nothing else to read. */
function key_perfect_ids(int $tid,int $pupil=0):array{
 $out=[];foreach(rows("SELECT c.id,c.activity_id FROM activity_completion c JOIN teacher_pupils t ON t.pupil_id=c.pupil_id JOIN activities a ON a.id=c.activity_id JOIN lessons l ON l.id=a.lesson_id JOIN modules m ON m.id=l.module_id WHERE t.teacher_id=? AND m.level_id IN (2,3,4,9,6,7,8) AND c.status IN ('completed','approved') AND c.reviewed_at IS NULL AND c.max_score>0 AND c.score>=c.max_score AND c.drawing IS NULL".($pupil?' AND c.pupil_id=?':''),$pupil?[$tid,$pupil]:[$tid]) as $r)if(key_fully_auto((int)$r['activity_id']))$out[]=(int)$r['id'];
 return $out;
}

/* ---------- Automatic checking (v151) ----------
   BULIG checks every answer the moment the pupil sends it, so nothing waits for the teacher. Cards with an answer key
   are marked right or wrong; spoken, drawn and written answers count as done. Right after "Done" (and whenever the
   activity is opened again) the pupil sees the score, stars and the right answer for anything missed, and can try the
   activity again for practice: the best score is kept and no extra XP is given. Teachers can still look at every
   answer, change a score or write a note on the pupil's page (Answers and scores). */
/** True when the activity is a card activity with an answer key, so BULIG can show a score. */
function ac_keyed(array $a):bool{static $c=[];$id=(int)$a['id'];if(isset($c[$id]))return $c[$id];
 if(!isset($a['lesson_id'],$a['title'],$a['prompt']))$a=one('SELECT * FROM activities WHERE id=?',[$id])??$a;
 return $c[$id]=isset($a['lesson_id'])&&in_array(lesson_level((int)$a['lesson_id']),[2,3,4,9,6,7,8],true)&&activity_key($a)&&l2a_set($a);}
/** What the pupil missed, in words a child can read: [[number, what, the right answer, 'goes with'|'is'], ...]. */
function ac_misses(array $a,array $s):array{
 $set=l2a_set($a);$key=activity_key($a)??[];if(!$set)return [];$bc=l2a_blank_counts($a,$set,lesson_level((int)$a['lesson_id']));$out=[];
 foreach($s['cards'] as $n=>$c){if($c['t']==='open'||($c['ok']??$c['pts']>=$c['of']))continue;$q=$set['cards'][$n-1]??[];$k=$key[$n]??null;if(!$k)continue;
  if($c['t']==='match'){$m=$q['match']??$q;$left=[];foreach(preg_split('/\n/',(string)($m['text']??'')) as $l)if(preg_match('/^\s*(\d+)\s*[.)]\s*(.*)$/',trim($l),$mm))$left[$mm[1]]=trim($mm[2]);
   $right=[];foreach(($m['choices']??[]) as $ch)if(preg_match('/^\s*([a-zA-Z])\s*[.)]\s*(.*)$/s',(string)$ch,$mm))$right[strtolower($mm[1])]=strtolower($mm[1]).'. '.trim($mm[2]);
   $have=[];if(preg_match_all('~(\d+)\s*-\s*([a-z])~i',$c['got'],$g,PREG_SET_ORDER))foreach($g as $x)$have[$x[1]]=strtolower($x[2]);
   foreach($k['a'] as $i=>$l)if(($have[(string)$i]??'')!==$l)$out[]=[(string)$i,($left[(string)$i]??'')!==''?$left[(string)$i]:'Number '.$i,$right[$l]??$l,'goes with'];}
  elseif($c['t']==='order')$out[]=[(string)$n,'The right order',implode(', ',array_map(fn($lab,$v)=>$lab.' = '.$v,array_keys($k['a']),$k['a'])),'is'];
  else{$t=blank_plain(trim(preg_replace('~\s+~u',' ',(string)($q['text']??''))),$bc[$n-1]??0);$out[]=[(string)$n,$t!==''?mb_strimwidth($t,0,90,'…'):'Card '.$n,$c['want'],'is']; }}
 return $out;
}
/* ---------- Stars (v181) ----------
   Every lesson activity (all levels) gives up to 3 stars: 95% or more = 3, 80% = 2, 50% = 1. The pupil needs 2 stars
   (80%) to go on to the next activity; below that the activity opens again for a fresh try. Post-tests give up to
   5 stars for the level's post-test score (95% = 5, 80% = 4, 60% = 3, 40% = 2, 20% = 1) and still need 80% to open the
   next level (app/post_gate.php). Pre-tests show the score only: they measure where the pupil starts. */
const STAR_PASS=80;
function star_of(string $phase):int{return $phase==='post'?5:($phase==='pre'?0:3);}
function star_count(float $frac,string $phase):int{$p=round($frac*100,6);
 if($phase==='pre')return 0;if($phase==='post')return $p>=95?5:($p>=80?4:($p>=60?3:($p>=40?2:($p>=20?1:0))));
 return $p>=95?3:($p>=80?2:($p>=50?1:0));}
function stars_html(int $n,int $of,string $cls=''):string{if($of<1)return '';$n=max(0,min($of,$n));return '<span class="ac-stars st'.$of.($cls!==''?' '.$cls:'').'" role="img" aria-label="'.$n.' of '.$of.' stars">'.str_repeat('<i></i>',$n).str_repeat('<i class="off"></i>',$of-$n).'</span>';}
/** Road map stars (v182): for each lesson id, ['of'=>3 (lesson) | 5 (post-test) | 0 (pre-test), 'n'=>stars won so far,
    'a'=>[[activity title, its stars], ...], 'ph'=>pre|learn|post]. An activity not done yet counts as 0; one done with no score counts as right. */
function map_stars(int $pid,array $lids):array{
 done_scores_repair();
 $lids=array_values(array_filter(array_map('intval',$lids)));if(!$lids)return [];$by=[];
 foreach(rows('SELECT a.id,a.lesson_id,a.title,a.phase,c.status,c.score,c.max_score FROM activities a LEFT JOIN activity_completion c ON c.activity_id=a.id AND c.pupil_id=? WHERE a.lesson_id IN ('.implode(',',$lids).') AND '.(function_exists('is_tester')&&is_tester($pid)?'(a.published=1 OR a.lesson_id IN (SELECT lesson_id FROM studio_lessons))':'a.published=1').' ORDER BY a.lesson_id,a.position',[$pid]) as $r)$by[(int)$r['lesson_id']][]=$r;
 $out=[];foreach($by as $lid=>$acts){
  /* Lessons with mixed phases (Levels 1 and 3A keep a small pre/post check inside each lesson): the stars come from the lesson activities. */
  $phs=array_unique(array_column($acts,'phase'));$ph=in_array('learn',$phs,true)?'learn':(in_array('post',$phs,true)?'post':'pre');
  $mx=null;if($ph==='learn'&&count($phs)>1){$mx=[];foreach(['pre','post'] as $k){$in=array_filter($acts,fn($r)=>$r['phase']===$k);if($in)$mx[$k]=[count(array_filter($in,'completion_ok')),count($in)];}if(count($mx)<2)$mx=null;}   // v183: the pre/post checks inside the lesson (Level 1)
  $acts=array_values(array_filter($acts,fn($r)=>$r['phase']===$ph));$of=star_of($ph);if(!$of){$out[$lid]=['of'=>0,'n'=>0,'a'=>[],'ph'=>$ph];continue;}
  $sum=0.0;$list=[];
  foreach($acts as $r){$ok=completion_ok($r);$fr=$ok?(completion_frac($r)??1.0):0.0;$sum+=$fr;$list[]=[(string)$r['title'],$ok?star_count($fr,'learn'):0];}
  $out[$lid]=['of'=>$of,'n'=>star_count($sum/count($acts),$ph),'a'=>$ph==='post'?[]:$list,'ph'=>$ph,'mx'=>$mx];}
 return $out;
}
/* ---------- v216 Play again and the Star Jars ----------
   A finished lesson activity can be played again. The new answer is scored like a first answer; BULIG keeps the better one.
   Going up a star gives +5 XP a star (2 → 3 stars). Playing an activity that already has 3 stars is practice: +2 XP, up to
   3 times a day for each activity. A lower score never lowers the stars. The first score is kept for the teacher
   (rubric_scores "first"). No new tables: the bonus XP is added to the activity's XP, and each play is in response_history. */
const REPLAY_XP_STAR=5,REPLAY_XP_PRACTICE=2,REPLAY_PRACTICE_DAY=3;
function replay_frac(?array $c):float{if(!$c)return 0.0;$f=completion_frac($c);return $f??(($c['status']??'')==='retry'?0.0:1.0);}
function replay_practice_left(int $cid):int{return max(0,REPLAY_PRACTICE_DAY-(int)val("SELECT COUNT(*) FROM response_history WHERE completion_id=? AND status='practice' AND created_at>=CURDATE()",[$cid]));}
function replay_settle(int $pid,array $a,array $old,int $cid):array{
 $new=one('SELECT * FROM activity_completion WHERE id=?',[$cid]);$fo=replay_frac($old);$fn=replay_frac($new);$so=star_count($fo,'learn');$sn=star_count($fn,'learn');$xp=0;
 $j=json_decode((string)($old['rubric_scores']??''),true);$first=is_array($j)&&isset($j['first'])?$j['first']:['score'=>$old['score'],'max'=>$old['max_score'],'at'=>$old['submitted_at']];
 if($sn>$so){/* a new best: keep the new answer */
  $nj=json_decode((string)($new['rubric_scores']??''),true);$nj=is_array($nj)?$nj:[];$nj['first']=$first;
  q("UPDATE activity_completion SET status='completed',rubric_scores=? WHERE id=?",[json_encode($nj,JSON_UNESCAPED_UNICODE),$cid]);
  $xp=REPLAY_XP_STAR*($sn-$so);$kind='best';$kept=true;}
 else{/* not better: the best answer stays, exactly as it was */
  $cols=array_values(array_filter(array_keys($old),fn($c)=>$c!=='id'&&preg_match('/^[a-z_]+$/',$c)));
  if($cols){$oj=is_array($j)?$j:[];$oj['first']=$first;$old['rubric_scores']=json_encode($oj,JSON_UNESCAPED_UNICODE);q('UPDATE activity_completion SET '.implode(',',array_map(fn($c)=>"`$c`=?",$cols)).' WHERE id=?',array_merge(array_map(fn($c)=>$old[$c],$cols),[$cid]));}
  $kept=false;
  if($so>=3&&$sn>=3){$kind='practice';if(replay_practice_left($cid)>0)$xp=REPLAY_XP_PRACTICE;}else $kind='keep';}
 if($xp>0){if(!q('UPDATE xp_transactions SET amount=amount+? WHERE pupil_id=? AND activity_id=?',[$xp,$pid,(int)$a['id']])->rowCount())q('INSERT IGNORE INTO xp_transactions(pupil_id,activity_id,amount) VALUES(?,?,?)',[$pid,(int)$a['id'],$xp]);
  q('INSERT INTO pupil_xp(pupil_id,total) VALUES(?,?) ON DUPLICATE KEY UPDATE total=total+VALUES(total)',[$pid,$xp]);}
 q('INSERT INTO response_history(completion_id,response,status,actor_id) VALUES(?,?,?,?)',[$cid,'Play again: '.$sn.' stars (best '.max($so,$sn).')'.($xp?' · +'.$xp.' XP':''),$kind==='practice'?'practice':'replay',$pid]);
 $msg=$kind==='best'?'New best! '.$sn.' stars now.':($kind==='practice'?($xp?'Great practice! Still 3 stars.':'Great practice! No more practice XP today for this one.'):'Your best stays '.$so.' stars.');
 return ['kept_new'=>$kept,'xp'=>$xp,'kind'=>$kind,'from'=>$so,'to'=>$sn,'stars'=>max($so,$sn),'pct'=>(int)floor(max($fo,$fn)*100+1e-9),'now'=>(int)floor($fn*100+1e-9),'left'=>$kind==='practice'?replay_practice_left($cid):null,'message'=>$msg];
}
/** The "Play again" bar under a finished lesson activity: its best stars and the button (pupils only). */
function replay_bar(array $a):string{
 $u=function_exists('current_user')?current_user():null;if(!$u||($u['role']??'')!=='pupil'||($a['phase']??'')!=='learn'||($a['response_mode']??'none')==='none'||!completion_ok($a))return '';
 $c=one('SELECT id,status,score,max_score FROM activity_completion WHERE pupil_id=? AND activity_id=?',[(int)$u['id'],(int)$a['id']]);if(!$c)return '';
 $st=star_count(replay_frac($c),'learn');$url='?page=lesson&amp;id='.(int)$a['lesson_id'].'&amp;activity='.(int)$a['id'].'&amp;again=1';
 if($st<3)return '<div class="rp-bar">'.stars_html($st,3).'<span class="rp-t">You got '.$st.' star'.($st===1?'':'s').'</span><a class="rp-btn gold" href="'.$url.'">'.l1_icon('again').'Play again for 3 stars</a><small>Get 3 stars: +'.REPLAY_XP_STAR.' XP for each new star, and more stars in your jar.</small></div>';
 $left=replay_practice_left((int)$c['id']);
 return '<div class="rp-bar rp-3">'.stars_html(3,3).'<span class="rp-t">Perfect! 3 stars</span><a class="rp-btn" href="'.$url.'">'.l1_icon('again').'Practice again</a><small>Practice for fun: +'.REPLAY_XP_PRACTICE.' XP'.($left?' ('.$left.' left today)':' (no more practice XP today)').'.</small></div>';
}
/** v216 On a finished lesson: every activity with its stars; those under 3 stars have Play again. */
function replay_list(array $lesson,array $all):string{
 $u=current_user();if(!$u||($u['role']??'')!=='pupil')return '';$rows='';$low=0;
 foreach(array_values($all) as $i=>$a){if(($a['phase']??'')!=='learn'||($a['response_mode']??'none')==='none'||!completion_ok($a))continue;
  $st=star_count(replay_frac($a),'learn');if($st<3)$low++;$url='?page=lesson&amp;id='.(int)$lesson['id'].'&amp;activity='.(int)$a['id'].($st<3?'&amp;again=1':'');
  $rows.='<a class="rp-row'.($st<3?' low':'').'" href="'.$url.'"><span class="rp-n">'.($i+1).'</span><span class="rp-tt">'.e((string)$a['title']).'</span>'.stars_html($st,3).'<span class="rp-go">'.($st<3?l1_icon('again').'Play again':'Open').'</span></a>';}
 if($rows==='')return '';
 return '<section class="card rp-list"><h2>'.icon('star').'Your activities</h2><p class="muted">'.($low?'Get 3 stars on '.($low===1?'1 activity':$low.' activities').' to fill your Star Jar. Each new star gives +'.REPLAY_XP_STAR.' XP.':'Perfect! Every activity has 3 stars.').'</p>'.$rows.'</section>';}
function replay_banner(array $a):string{$u=current_user();$c=one('SELECT status,score,max_score FROM activity_completion WHERE pupil_id=? AND activity_id=?',[(int)$u['id'],(int)$a['id']]);$st=star_count(replay_frac($c),'learn');
 return '<div class="ac-practice rp-banner">'.l1_icon('again').'<div><b>'.($st<3?'Play again for 3 stars':'Practice again').'</b><p>Your best now: '.$st.' star'.($st===1?'':'s').'. BULIG Quest keeps your best score.</p></div></div>';}
/** v216 The floating Star Jar on the road map (bottom left). Tap it: Zion the Star Keeper says how many stars are in it. */
function star_jar_svg():string{return '<svg viewBox="0 0 84 100" aria-hidden="true"><defs><linearGradient id="sjg" x1="0" x2="1"><stop offset="0" stop-color="#e9f6ff"/><stop offset=".5" stop-color="#fff"/><stop offset="1" stop-color="#d7ecfa"/></linearGradient><linearGradient id="sjo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe680"/><stop offset="1" stop-color="#f2b10c"/></linearGradient><linearGradient id="sjl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffcf3a"/><stop offset="1" stop-color="#c98200"/></linearGradient><clipPath id="sjc"><path d="M14 30c0-4 3-6 6-6h44c3 0 6 2 6 6v54c0 6-5 10-10 10H24c-5 0-10-4-10-10z"/></clipPath></defs><rect x="18" y="6" width="48" height="14" rx="6" fill="url(#sjl)"/><rect x="16" y="18" width="52" height="8" rx="4" fill="#c98200"/><path d="M14 30c0-4 3-6 6-6h44c3 0 6 2 6 6v54c0 6-5 10-10 10H24c-5 0-10-4-10-10z" fill="url(#sjg)" stroke="#a9d1ee" stroke-width="2.5"/><g clip-path="url(#sjc)"><path class="sj-fill" d="M10 48q16-8 32-2t32-4v60H10z" fill="url(#sjo)"/><g fill="#fff6c2" stroke="#e0a000" stroke-width="1"><path d="M27 58l2.4 5 5.4.6-4 3.7 1.1 5.3L27 70l-4.9 2.6 1.1-5.3-4-3.7 5.4-.6z"/><path d="M52 52l2 4.2 4.6.5-3.4 3.1.9 4.5-4.1-2.3-4.1 2.3.9-4.5-3.4-3.1 4.6-.5z"/><path d="M44 72l2.6 5.4 5.9.7-4.4 4 1.2 5.8L44 85l-5.3 2.9 1.2-5.8-4.4-4 5.9-.7z"/><path d="M24 80l1.8 3.8 4.1.5-3 2.8.8 4L24 89l-3.7 2.1.8-4-3-2.8 4.1-.5z"/><path d="M60 78l1.8 3.8 4.1.5-3 2.8.8 4L60 87l-3.7 2.1.8-4-3-2.8 4.1-.5z"/></g></g><path d="M22 34c-2 10-2 34 0 52" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".75" fill="none"/></svg>';}
function star_jar_float(int $pid,int $level):string{
 $j=star_jar($pid,$level);if(!$j['of'])return '';$n=$j['n'];$of=$j['of'];$left=$of-$n;$pct=(int)round($n/$of*100);
 $title=$level?'Star Jar · '.level_label($level):'Big Star Jar · All levels';
 $say=$left<=0?'Your jar is full! You are a star reader!':($n?'Great collecting! Play again any activity with 1 or 2 stars to fill your jar.':'Earn stars in every activity, and I will keep them in your jar!');
 /* a small jar in the corner; tapping it opens a popup in the middle (v216) */
 return '<details class="sjar'.($left<=0?' full':'').'"><summary aria-label="Star Jar: '.$n.' of '.$of.' stars"><span class="sj-ring">'.star_jar_svg().'</span><span class="sj-cnt"><b>★</b> '.$n.' / '.$of.'</span></summary>'
  .'<div class="sj-pop" role="dialog" aria-modal="true" aria-label="'.e($title).'"><span class="sj-shade" data-sj-close></span><div class="sj-card">'
  .'<button type="button" class="sj-x" data-sj-close aria-label="Close">✕</button>'
  .'<div class="sj-top"><span class="sj-big">'.star_jar_svg().'</span><img src="'.e(friend_img('zion',$left<=0?'cheer':'point')).'" alt="" width="110" height="132"></div>'
  .'<span class="sj-h">★ '.e(mb_strtoupper($title)).'</span><span class="sj-n">'.$n.' <small>/ '.$of.' stars</small></span><span class="sj-bar"><i class="p'.(int)(round($pct/5)*5).'"></i></span>'
  .'<p class="sj-say"><b>Zion the Star Keeper</b>'.e($say).'</p><button type="button" class="sj-ok" data-sj-close>Keep going</button></div></div></details>';
}
/** The best stars of each finished lesson activity: [activity id => stars]. */
function star_jar(int $pid,int $level=0):array{
 static $c=[];$k=$pid.':'.$level;if(isset($c[$k]))return $c[$k];
 $g=function_exists('pupil_grade')?pupil_grade($pid):null;$tester=function_exists('is_tester')&&is_tester($pid);
 $levels=$level?[$level]:(function_exists('level_sequence')?level_sequence():array_map('intval',array_column(rows('SELECT id FROM bulig_levels ORDER BY id'),'id')));$n=0;$of=0;
 foreach($levels as $lv){$lids=array_map('intval',array_column(rows('SELECT l.id FROM lessons l JOIN modules m ON m.id=l.module_id JOIN bulig_levels b ON b.id=m.level_id WHERE m.level_id=? AND '.($tester&&function_exists('studio_pub_sql')?studio_pub_sql('l',$pid):'l.published=1 AND b.published=1').GRADE_SQL,[$lv,$g]),'id'));
  if(!$lids)continue;foreach(map_stars($pid,$lids) as $m){if(empty($m['of']))continue;$n+=(int)$m['n'];$of+=(int)$m['of'];}}   // v216 the same stars as on the road map: up to 3 a lesson, 5 on the post-test
 return $c[$k]=['n'=>$n,'of'=>$of];
}
/** The friend who cheers on the Victory popup: the friend of the activity's skill. */
function vx_friend(array $a):string{$lv=function_exists('level_family')?level_family(lesson_level((int)$a['lesson_id'])):lesson_level((int)$a['lesson_id']);
 if(in_array($lv,[2,3,4],true))return 'mia';if($lv>=6&&$lv<=8)return 'dracs';return 'max';}
/** A saved answer's share right (0 to 1), or null when it has no score. */
function completion_frac(?array $c):?float{return $c&&$c['max_score']!==null&&(float)$c['max_score']>0?max(0,min(1,(float)$c['score']/(float)$c['max_score'])):null;}
/** The card shown when a lesson activity is below 2 stars: the stars, the score and a fresh "Try again". */
function star_gate_card(array $a,float $frac):string{$st=star_count($frac,'learn');$pct=(int)floor($frac*100+1e-9);
 return '<div class="ac-panel sg-panel" role="status"><div class="ac-top"><span class="ac-badge sg-badge" aria-hidden="true">'.l1_icon('again').'</span><div><b>'.($st?'You got '.$st.' star'.($st>1?'s':'').'!':'Let’s try again!').'</b><small>Your score is '.$pct.'%. You need 2 stars ('.STAR_PASS.'%) to go on.</small></div></div>'
  .'<div class="ac-score"><strong>'.$pct.'%</strong>'.stars_html($st,3).'</div>'
  .(function_exists('friend_say')?friend_say('bruno','tryagain','You can do it! Try this activity again and get 2 stars.',false):'')
  .'<div class="ac-btns"><a class="ac-btn" href="?page=lesson&amp;id='.(int)$a['lesson_id'].'&amp;activity='.(int)$a['id'].'">'.l1_icon('again').'Try again</a></div></div>';}

/** The result card. $c: the saved answer (response, score, max_score, rubric_scores, submitted_at).
    $o: fresh (just sent), xp, practice (a "try again" answer), best (the score that is kept). */
function ac_card(array $a,array $c,array $o=[]):string{
 if(!ac_keyed($a))return '';$s=key_score($a,(string)($c['response']??''));if(!$s||!$s['total'])return '';
 /* v216 Pre-test: nothing is "wrong" for the pupil. BULIG thanks them and shows the answers; the real score is kept for the teacher. */
 if(($a['phase']??'')==='pre'){$u0=function_exists('current_user')?current_user():null;if($u0&&($u0['role']??'')==='pupil'){$miss=ac_misses($a,$s);
  $h='<div class="ac-panel ac-pre" role="status"><div class="ac-top"><span class="ac-badge" aria-hidden="true">'.l1_icon('ok').'</span><div><b>Thank you! This part is done.</b><small>The pre-test shows what you know now. There is no wrong answer here.</small></div></div>';
  if($miss){$h.='<p class="ac-lab">LET’S LEARN THESE</p><ul class="ac-again ac-learn">';foreach(array_slice($miss,0,8) as [$n,$what,$want,$how])$h.='<li><em>'.e($n).'</em><span>'.($how==='goes with'?e($what).' goes with <b>'.e($want).'</b>':e($what).'<br>The answer is <b>'.e($want).'</b>').'</span></li>';if(count($miss)>8)$h.='<li class="ac-more"><span>and '.(count($miss)-8).' more</span></li>';$h.='</ul>';}
  return $h.(function_exists('friend_say')?friend_say('george','thumbs','Great start! We will learn all of these together in the lessons.',false):'').'</div>';}}
 $right=$s['right'];$total=$s['total'];$j=json_decode((string)($c['rubric_scores']??''),true);$teacher=is_array($j)&&isset($j['teacher_score'])&&empty($o['fresh']);
 if($teacher&&(float)($c['max_score']??0)>0){$right=(float)$c['score'];$total=(float)$c['max_score'];}
 $num=fn($x)=>rtrim(rtrim(number_format((float)$x,1),'0'),'.');$pct=$total?$right/$total:0;$ph=(string)($a['phase']??'learn');
 $title=!empty($o['practice'])?'Practice checked!':($pct>=1?'Perfect! Every answer is right.':($pct>=.8?'Great work!':($pct>=.5?'Good try!':'Let’s look again together.')));
 $sub=!empty($o['practice'])?(string)($o['best']??''):(!empty($o['fresh'])?'BULIG Quest checked your answers.':($teacher?'Your teacher checked this.':'BULIG Quest checked this'.(!empty($c['submitted_at'])?' on '.date('F j',strtotime((string)$c['submitted_at'])):'').'.'));
 $h='<div class="ac-panel'.($pct>=1?' ac-perfect':'').'" role="status"><div class="ac-top"><span class="ac-badge" aria-hidden="true">'.l1_icon('ok').'</span><div><b>'.e($title).'</b><small>'.e($sub).'</small></div></div>';
 $h.='<div class="ac-score"><strong>'.$num($right).' <span>of '.$num($total).' right</span></strong>'.($ph==='learn'?stars_html(star_count($pct,'learn'),3):'').'</div>';   // v181: 3 stars on lesson activities; post-tests get 5 stars for the whole level
 if(!empty($o['xp']))$h.='<span class="ac-xp">+'.(int)$o['xp'].' XP</span>';
 if(!$teacher&&$pct<1&&($miss=ac_misses($a,$s))){$h.='<p class="ac-lab">LOOK AGAIN</p><ul class="ac-again">';
  foreach(array_slice($miss,0,6) as [$n,$what,$want,$how])$h.='<li><em>'.e($n).'</em><span>'.($how==='goes with'?e($what).' goes with <b>'.e($want).'</b>':e($what).'<br>The answer: <b>'.e($want).'</b>').'</span></li>';
  if(count($miss)>6)$h.='<li class="ac-more"><span>and '.(count($miss)-6).' more</span></li>';$h.='</ul>';}
 if($pct<1&&!$teacher&&function_exists('friend_say'))$h.=friend_say('bruno','tryagain','Made a mistake? That is okay! Tap Try it again and we will do it together.',false);
 if(false&&$pct<1&&!$teacher)$h.='<div class="ac-btns"><a class="ac-btn" href="?page=lesson&amp;id='.(int)$a['lesson_id'].'&amp;activity='.(int)$a['id'].'&amp;again=1">'.l1_icon('again').'Try it again</a></div>';
 return $h.'</div>';
}
/** "Try it again": mark the new answer, keep the best one. No XP and no change to the pupil's progress. */
function ac_practice(int $pid,array $a,array $old,string $answer):array{
 $new=key_score($a,$answer);$j=json_decode((string)($old['rubric_scores']??''),true);$locked=is_array($j)&&isset($j['teacher_score']);
 $prev=$old['score']!==null&&$old['max_score']!==null?['right'=>(float)$old['score'],'total'=>(float)$old['max_score']]:key_score($a,(string)$old['response']);/* answers saved before scores were kept are marked now */
 $was=(float)($prev['right']??0);$better=!$locked&&$new&&$new['right']>$was;
 if($better){q('UPDATE activity_completion SET response=?,score=?,max_score=? WHERE id=?',[$answer,$new['right'],$new['total'],(int)$old['id']]);}
 q('INSERT INTO response_history(completion_id,response,status,actor_id) VALUES(?,?,?,?)',[(int)$old['id'],$answer,'practice',$pid]);
 $num=fn($x)=>rtrim(rtrim(number_format((float)$x,1),'0'),'.');$best=$better?$new['right']:$was;$of=$better?$new['total']:(float)($prev['total']??($new['total']??0));
 $msg=$better?'Better! Your new best score is '.$num($best).' of '.$num($of).'.':'Your best score stays '.$num($best).' of '.$num($of).'.';
 return ['message'=>$msg,'card'=>ac_card($a,['response'=>$answer],['fresh'=>true,'practice'=>true,'best'=>$msg])];
}


/* v216 Roxanne the Timekeeper: how long each activity takes (the seconds the activity page was open in front of the
   pupil; the browser stops counting when the pupil leaves the page). The pupil sees the time and their fastest time; the teacher
   sees it on each answer, in red when it is much slower than the class usually takes. Needs 048_activity_time.sql. */
function rx_ready():bool{static $r;if($r===null){try{$r=(bool)one("SHOW COLUMNS FROM activity_completion LIKE 'best_secs'");}catch(Throwable $e){$r=false;}}return $r;}
function rx_fmt(int $s):string{$m=intdiv($s,60);$x=$s%60;return $m?$m.' min'.($x?' '.sprintf('%02d',$x).' s':''):$x.' s';}
function rx_class_avg(int $aid):?int{static $c=[];if(!array_key_exists($aid,$c)){$v=one('SELECT AVG(best_secs) a,COUNT(*) n FROM activity_completion WHERE activity_id=? AND best_secs BETWEEN 3 AND 7200',[$aid]);$c[$aid]=$v&&(int)$v['n']>=3?(int)round((float)$v['a']):null;}return $c[$aid];}
function rx_save(int $pid,int $aid,int $secs):void{
 if($secs<1||$secs>7200||!rx_ready())return;$old=one('SELECT best_secs,status FROM activity_completion WHERE pupil_id=? AND activity_id=?',[$pid,$aid]);if(!$old)return;
 $done=($old['status']??'')!=='retry';$prev=$old['best_secs']!==null?(int)$old['best_secs']:null;
 q('UPDATE activity_completion SET time_secs=?'.($done?',best_secs=IF(best_secs IS NULL OR best_secs>?,?,best_secs)':'').' WHERE pupil_id=? AND activity_id=?',$done?[$secs,$secs,$secs,$pid,$aid]:[$secs,$pid,$aid]);
 $GLOBALS['bulig_rx']=['t'=>$secs,'prev'=>$prev,'best'=>$done&&($prev===null||$secs<$prev),'avg'=>rx_class_avg($aid)];}
function rx_card(array $r):string{
 $t=(int)$r['t'];$tags='';
 if(!empty($r['best'])&&$r['prev']!==null)$tags.='<span class="g">New fastest time!</span><span>Before: '.e(rx_fmt((int)$r['prev'])).'</span>';
 elseif($r['prev']!==null)$tags.='<span>Your fastest: '.e(rx_fmt((int)$r['prev'])).'</span>';
 if(!empty($r['avg']))$tags.='<span>Your class usually: '.e(rx_fmt((int)$r['avg'])).'</span>';
 $say=['Tick, tock! You finished in ','Right on time! That took ','Tick, tock! Your time: '][$t%3];
 return '<div class="rx-res" role="status"><img src="assets/images/characters/roxanne-cheer.webp" alt="" width="70" height="70"><div><b>ROXANNE THE TIMEKEEPER</b><p>'.e($say.rx_fmt($t)).'.</p>'.($tags?'<div class="rx-tags">'.$tags.'</div>':'').'</div></div>';}
/** the time tag on a teacher's answer row: red when it took much longer than the class usually takes */
function rx_tag(array $c):string{
 if(!rx_ready()||empty($c['time_secs']))return '';$t=(int)$c['time_secs'];$avg=rx_class_avg((int)$c['activity_id']);$slow=$avg&&$t>=60&&$t>2*$avg;
 return '<span class="rx-tag'.($slow?' slow':'').'" title="'.e($slow?'Much slower than the class usually takes ('.rx_fmt($avg).')':'Time on this activity'.($avg?' · class usually '.rx_fmt($avg):'')).'"><img src="assets/images/characters/roxanne-time.webp?v=2" alt="" width="18" height="18">'.e(rx_fmt($t)).'</span>';}
