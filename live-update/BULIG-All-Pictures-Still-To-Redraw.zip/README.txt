BULIG - all pictures still to redraw (20)
Every other picture in Levels 1 to 7 is already redrawn.

LEVEL 3 (6) - folder level3
These 6 came back damaged in "BULIG-Level-3-Redrawn-Progress.zip": a piece of the
old picture was left stuck on. The damaged copies are in
"level3-damaged-versions-do-not-use" so you can see the problem.
  l01-build-01  car (a second half-car is pasted over the letter boxes)
  l01-build-06  cap (an extra cap brim under the cap)
  l05-build-06  bun (half of the old photo bun under the new bun)
  l05-build-08  sun with sunglasses (half of the old sun under the new sun)
  l11-fill-06   broken mirror  "_ _ oken"  (a piece of the old mirror on the right)
  l11-fill-07   broom  "_ _ oom"  (a stray stroke at the top right)
For the 4 "build" pictures keep the letter boxes and lines exactly as they are;
redraw only the picture at the top.

LEVEL 5 GRADE 1 (14) - folder level5/g1
  13 old stock photos with a "shutterstock" watermark (4 different pictures):
    grandfather: m008-5, m096-1, p008-5, p096-5
    carrots:     m012-3, m058-1, m101-6, p012-3, p058-1
    banana:      m030-2, p030-2
    dictionary:  m067-1, p067-1
  1 picture that arrived broken: p067-2

When redrawing: keep each file name exactly the same, keep the same shape
(width and height), save as .webp, and put them back in the same folders.
