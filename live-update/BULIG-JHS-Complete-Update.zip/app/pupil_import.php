<?php
/** Bulk pupil import: read a class list (CSV, Excel .xlsx or .xls such as the DepEd SF1 from LIS), check every row, then create the accounts. */
const IMPORT_MAX_ROWS=300;

function create_pupil_account(array $teacher,string $name,array $section,int $level,array $details,?array $parts=null):string{
 $public=new_account_id('pupil');
 q('INSERT INTO users(public_id,role,name,password_hash) VALUES(?,?,?,?)',[$public,'pupil',$name,password_hash('12345678',PASSWORD_DEFAULT)]);$id=(int)db()->lastInsertId();name_parts_save($id,$parts);school_mark_user($id,user_school_id((int)$teacher['id'])?:null);
 q('INSERT INTO pupils(user_id,grade_level,section) VALUES(?,?,?)',[$id,(int)$section['grade_level'],$section['name']]);save_pupil_details($id,$details);
 q('INSERT INTO pupil_sections VALUES(?,?)',[$id,$section['id']]);q('INSERT INTO teacher_pupils VALUES(?,?)',[$teacher['id'],$id]);
 if($level)q('INSERT INTO pupil_level_assignments(pupil_id,level_id,assigned_by) VALUES(?,?,?)',[$id,$level,$teacher['id']]);
 $GLOBALS['last_starter_pw']=new_pupil_password($id);
 return $public;
}

/** Rows of cell strings from an uploaded .csv, .xlsx or .xls file. */
function import_read_file(string $path,string $original):array{
 $ext=strtolower(pathinfo($original,PATHINFO_EXTENSION));
 if($ext==='xls'){require_once __DIR__.'/xls_reader.php';return xls_read($path,IMPORT_MAX_ROWS);}
 if($ext==='xlsx')return import_read_xlsx($path);
 if(!in_array($ext,['csv','txt'],true))fail('Upload a CSV file or an Excel file (.xlsx or .xls).');
 $text=(string)file_get_contents($path);
 if(str_starts_with($text,"\xFF\xFE")||str_starts_with($text,"\xFE\xFF"))$text=mb_convert_encoding(substr($text,2),'UTF-8',str_starts_with($text,"\xFF\xFE")?'UTF-16LE':'UTF-16BE');
 $text=preg_replace('/^\xEF\xBB\xBF/','',$text);
 if(!mb_check_encoding($text,'UTF-8'))$text=mb_convert_encoding($text,'UTF-8','Windows-1252');
 $first=strtok($text,"\n")?:'';$delims=[','=>substr_count($first,','),';'=>substr_count($first,';'),"\t"=>substr_count($first,"\t")];arsort($delims);$d=array_key_first($delims);
 $h=fopen('php://memory','r+');fwrite($h,$text);rewind($h);$rows=[];
 while(($r=fgetcsv($h,0,$d,'"','\\'))!==false){$rows[]=array_map(fn($c)=>trim((string)$c),$r);if(count($rows)>IMPORT_MAX_ROWS+20)break;}
 fclose($h);return $rows;
}
function import_read_xlsx(string $path):array{
 if(!class_exists('ZipArchive'))fail('This server cannot read Excel files. In Excel choose File → Save As → CSV, then upload the CSV.');
 $z=new ZipArchive();if($z->open($path)!==true)fail('The Excel file could not be opened. Save it again as .xlsx or CSV.');
 $strings=[];
 if(($x=$z->getFromName('xl/sharedStrings.xml'))!==false){$doc=import_xml($x);foreach($doc->si as $si){$t='';if(isset($si->t))$t=(string)$si->t;foreach($si->r as $r)$t.=(string)$r->t;$strings[]=$t;}}
 $sheet='xl/worksheets/sheet1.xml';
 if(($wb=$z->getFromName('xl/workbook.xml'))!==false&&($rels=$z->getFromName('xl/_rels/workbook.xml.rels'))!==false){
  $w=import_xml($wb);$first=$w->sheets->sheet[0]??null;
  if($first){$rid=(string)$first->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
   foreach(import_xml($rels)->Relationship as $rel)if((string)$rel['Id']===$rid){$t=ltrim((string)$rel['Target'],'/');$sheet=str_starts_with($t,'xl/')?$t:'xl/'.$t;}}
 }
 $x=$z->getFromName($sheet);$z->close();if($x===false)fail('The Excel file has no readable sheet. Save it again as .xlsx or CSV.');
 $rows=[];
 foreach(import_xml($x)->sheetData->row as $row){$cells=[];$rn=(int)$row['r'];while($rn>0&&count($rows)<$rn-1)$rows[]=[];   // keep Excel row numbers
  foreach($row->c as $c){preg_match('/^([A-Z]+)/',(string)$c['r'],$m);$col=0;foreach(str_split($m[1]??'A') as $ch)$col=$col*26+ord($ch)-64;$type=(string)$c['t'];
   $v=$type==='s'?($strings[(int)$c->v]??''):($type==='inlineStr'?(string)$c->is->t:(string)$c->v);
   if(($type===''||$type==='n')&&preg_match('/^-?\d+(\.\d+)?E\+?\d+$/i',$v))$v=sprintf('%.0f',(float)$v);
   if(($type===''||$type==='n')&&preg_match('/^\d+\.0+$/',$v))$v=preg_replace('/\.0+$/','',$v);
   $cells[$col-1]=trim($v);}
  $r=[];if($cells){$max=max(array_keys($cells));for($i=0;$i<=$max;$i++)$r[]=$cells[$i]??'';}$rows[]=$r;
  if(count($rows)>IMPORT_MAX_ROWS+20)break;}
 return $rows;
}
function import_xml(string $x):SimpleXMLElement{$prev=libxml_use_internal_errors(true);$d=simplexml_load_string($x,'SimpleXMLElement',LIBXML_NONET);libxml_use_internal_errors($prev);if(!$d)fail('The Excel file could not be read. Save it again as .xlsx or CSV.');return $d;}

/** Which column holds what: header words people use on class lists (and DepEd SF1). */
function import_columns(array $header):array{
 $alias=['name'=>['name','full name','fullname','learner name','learners name','pupil name','name of learner','name of pupil','student name','complete name'],
  'last'=>['last name','lastname','surname','family name','apelyido'],'first'=>['first name','firstname','given name','pangalan'],'middle'=>['middle name','middlename','middle initial','mi'],'ext'=>['extension','ext','name extension','extension name','suffix','jr sr'],
  'lrn'=>['lrn','learner reference number','lrn no','lrn number','learner reference no'],'sex'=>['sex','gender','m f','kasarian'],'section'=>['section','class','seksyon'],
  'grade'=>['grade','grade level','gr'],'support'=>['reading support','support','speech support','speech','listening','how bulig listens'],'level'=>['starting level','bulig level','level','start level']];
 $cols=[];
 foreach($header as $i=>$h){$k=trim(preg_replace('/\s+/',' ',preg_replace('/[^a-z0-9]+/',' ',strtolower($h))));
  foreach($alias as $key=>$words)if(!isset($cols[$key])&&in_array($k,$words,true)){$cols[$key]=$i;continue 2;}
  // looser headers, e.g. SF1 "NAME (Last Name, First Name, Middle Name)" or "LRN No."
  if(!isset($cols['lrn'])&&preg_match('/\blrn\b/',$k))$cols['lrn']=$i;
  elseif(!isset($cols['name'])&&!isset($cols['last'])&&str_starts_with($k,'name'))$cols['name']=$i;
  elseif(!isset($cols['sex'])&&preg_match('/^(sex|gender)\b/',$k))$cols['sex']=$i;}
 return $cols;
}
function import_name_case(string $s):string{$s=trim(preg_replace('/\s+/',' ',$s));return $s!==''&&(str_replace('ñ','Ñ',$s)===mb_strtoupper($s)||$s===mb_strtolower($s))?mb_convert_case(mb_strtolower($s),MB_CASE_TITLE,'UTF-8'):$s;}
function import_level(string $v,int $default):?int{
 $v=strtoupper(trim(str_ireplace('level','',$v)));if($v==='')return $default;if(in_array($v,['BULIG','CHECK','READING CHECK','?'],true)&&function_exists('rc_ready')&&rc_ready())return 0;
 $map=['1'=>1,'2A'=>2,'2B'=>3,'3'=>4,'3A'=>4,'3B'=>9,'4'=>5,'5'=>6,'6'=>7,'7'=>8];return $map[$v]??null;
}

/** DepEd SF1 (School Register): the grade and section are written once above the table ("Grade Level  Grade 6", "Section  ROSE"). */
function import_sheet_class(array $rows,int $headerRow):array{
 $out=[];foreach(array_slice($rows,0,$headerRow) as $r){$r=array_values($r);foreach($r as $i=>$c){$k=strtolower(trim(preg_replace('/\s+/',' ',$c)));$key=$k==='grade level'||$k==='grade level:'?'grade':($k==='section'||$k==='section:'?'section':null);
  if($key&&!isset($out[$key]))for($j=$i+1;$j<count($r);$j++)if(trim($r[$j])!==''){$out[$key]=trim($r[$j]);break;}}}
 if(isset($out['grade'])){$g=(int)preg_replace('/\D/','',$out['grade']);$out['grade']=grade_ok($g)?$g:0;}
 return $out;
}
/** SF1 names: "DELA CRUZ,JUAN JR., SANTOS" (last, first, middle). Returns [first, middle, last, extension]. */
function import_sf1_name(string $name):?array{
 $p=array_map('trim',explode(',',$name));if(count($p)<3||$p[0]===''||$p[1]==='')return null;
 [$last,$first]=$p;$middle=trim(implode(' ',array_slice($p,2)));$ext='';
 if(preg_match('/^(.*\S)\s+(JR\.?|SR\.?|II|III|IV)$/i',$first,$m)){$first=$m[1];$ext=(string)name_ext_norm($m[2]);}
 return [import_name_case($first),import_name_case($middle),import_name_case($last),$ext];
}

/** Check every row; nothing is saved yet. */
function import_check(array $rows,array $teacher,int $defaultSection,int $defaultLevel):array{
 $hi=null;foreach(array_slice($rows,0,10,true) as $i=>$r){$c=import_columns($r);if(isset($c['name'])||isset($c['last'])||isset($c['first'])){$hi=$i;$cols=$c;break;}}
 if($hi===null)fail('No header row found. The first row must have column names such as Name (or Last name and First name), LRN, Sex and Section. Download the template to see the format.');
 $sheet=isset($cols['section'])?[]:import_sheet_class($rows,$hi);$sf1=isset($sheet['section']);
 $sections=teacher_sections((int)$teacher['id']);$default=null;foreach($sections as $s)if((int)$s['id']===$defaultSection)$default=$s;
 $out=[];$seenLrn=[];$seenName=[];$newSeen=[];
 foreach(array_slice($rows,$hi+1) as $n=>$r){
  $get=fn($k)=>isset($cols[$k])?trim((string)($r[$cols[$k]]??'')):'';
  if(!array_filter($r,fn($c)=>trim((string)$c)!==''))continue;
  if($sf1&&preg_match('/^list and code/i',trim((string)($r[0]??''))))break;   // SF1: the legend and signatures come after the pupils
  if(str_starts_with($get('name'),'<==')||($sf1&&$get('name')===''))continue;     // SF1: "<=== TOTAL MALE" lines
  if(count($out)>=IMPORT_MAX_ROWS)fail('A class list can have up to '.IMPORT_MAX_ROWS.' pupils per upload. Split the file and upload it in parts.');
  $name=$get('name');$sfName=$name!==''?import_sf1_name($name):null;
  if($name!==''&&substr_count($name,',')===1){[$l,$f]=array_map('trim',explode(',',$name));if($l!==''&&$f!=='')$name=$f.' '.$l;}   // "DELA CRUZ, JUAN S." -> "JUAN S. DELA CRUZ"
  $ext=name_ext_norm($get('ext'));$parts=null;$full='';
  if($sfName){[$f,$m,$l,$x]=$sfName;$ext=$ext?:$x;$name=name_compose($f,$m,$l,(string)$ext);$full=trim(preg_replace('/\s+/',' ',"$f $m $l $ext"));$parts=[$f,$m,$l,(string)$ext];}
  elseif($name===''){[$f,$m,$l]=[import_name_case($get('first')),import_name_case($get('middle')),import_name_case($get('last'))];$name=name_compose($f,$m,$l,(string)$ext);$full=trim(preg_replace('/\s+/',' ',"$f $m $l $ext"));if($f!==''&&$l!=='')$parts=[$f,$m,$l,(string)$ext];}
  else $name=trim(import_name_case($name).' '.$ext);
  $name=trim(preg_replace('/\s+/',' ',$name));
  $lrn=preg_replace('/[\s\-\'’]/','',$get('lrn'));$sexRaw=strtolower($get('sex'));
  $sex=in_array($sexRaw,['m','male','boy','lalaki','l'],true)?'male':(in_array($sexRaw,['f','female','girl','babae','b'],true)?'female':null);
  $row=['line'=>$hi+$n+2,'name'=>$name,'parts'=>$parts,'lrn'=>$lrn,'sex'=>$sex,'section'=>null,'new_section'=>null,'grade'=>null,'level'=>$defaultLevel,'support'=>function_exists('speech_parse')?speech_parse($get('support')):'standard','status'=>'ok','notes'=>[]];
  $err=function(string $m)use(&$row){$row['status']='error';$row['notes'][]=$m;};
  if(mb_strlen($name)<2||mb_strlen($name)>150)$err('Name is missing or too long.');
  elseif(!isset($cols['name'])&&($get('first')===''||$get('last')===''))$err($get('first')===''?'First name is missing.':'Last name is missing.');
  if($ext===null)$err('Extension must be Jr., Sr., II, III, IV or V (or blank).');
  if(!$sex)$err($sexRaw===''?'Sex is missing (M or F).':'Sex must be M or F.');
  if($lrn!==''&&!preg_match('/^[0-9]{12}$/D',$lrn))$err('LRN must be 12 digits (or leave it blank).');
  $grade=$get('grade');$grade=$grade!==''?(int)preg_replace('/\D/','',$grade):0;
  $secName=$get('section');if($secName===''&&!$default&&$sf1){$secName=$sheet['section'];$grade=$grade?:(int)($sheet['grade']??0);}   // SF1: the class written above the table
  if($secName!==''){
   $match=null;foreach($sections as $s)if(strcasecmp(trim($s['name']),$secName)===0&&(!$grade||(int)$s['grade_level']===$grade))$match=$s;
   if($match)$row['section']=$match;
   elseif(grade_ok($grade)){$row['new_section']=['name'=>mb_substr($sf1?$secName:import_name_case($secName),0,80),'grade_level'=>$grade];$nk=mb_strtolower($secName).'|'.$grade;if(!isset($newSeen[$nk])){$newSeen[$nk]=1;$row['notes'][]='New section “'.($sf1?$secName:import_name_case($secName)).'” (Grade '.$grade.') will be added.';}}
   elseif($default)$err('Section “'.$secName.'” is not one of your sections. Add a Grade column or create the section first.');
   else $err('Section “'.$secName.'” is not one of your sections. Add a Grade column or create the section first.');
  }elseif($default)$row['section']=$default;
  else $err('Section is missing. Add a Section column or choose a section for the whole list.');
  $sec=$row['section']??$row['new_section'];if($sec)$row['grade']=(int)$sec['grade_level'];
  $lv=import_level($get('level'),$defaultLevel);if($lv===null||($lv!==0&&!val('SELECT id FROM bulig_levels WHERE id=?',[$lv])))$err('Starting level “'.$get('level').'” is not a BULIG level (use 1, 2A, 2B, 3A, 3B, 4, 5, 6 or 7).');else $row['level']=$lv;
  if($row['status']==='ok'){
   if($lrn!==''&&isset($seenLrn[$lrn]))$err('Same LRN as line '.$seenLrn[$lrn].' in this file.');
   elseif($lrn!==''&&val('SELECT pupil_id FROM pupil_details WHERE lrn=?',[$lrn])){$row['status']='skip';$row['notes'][]='Already in BULIG (same LRN).';}
   else{$key=mb_strtolower($name).'|'.($sec['name']??'').'|'.$row['grade'];
    if(isset($seenName[$key]))$err('Same name and section as line '.$seenName[$key].' in this file.');
    elseif($row['section']&&val('SELECT 1 FROM users u JOIN pupil_sections ps ON ps.pupil_id=u.id JOIN teacher_pupils t ON t.pupil_id=u.id WHERE t.teacher_id=? AND ps.section_id=? AND LOWER(u.name) IN (LOWER(?),LOWER(?))',[$teacher['id'],$row['section']['id'],$name,$full?:$name])){$row['status']='skip';$row['notes'][]='Already in this section (same name).';}
    $seenName[$key]=$row['line'];}
   if($lrn!=='')$seenLrn[$lrn]=$row['line'];
  }
  $out[]=$row;
 }
 if(!$out)fail('The file has a header row but no pupils under it.');
 return $out;
}

function import_actions(string $action):void{
 if($action==='import_preview'){
  $u=require_role('teacher');$f=$_FILES['class_list']??null;
  if(!$f||($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)fail(($f['error']??0)===UPLOAD_ERR_INI_SIZE||($f['error']??0)===UPLOAD_ERR_FORM_SIZE?'The file is too big. Keep it under 2 MB.':'Choose a CSV or Excel file to upload.');
  if($f['size']>2*1024*1024)fail('The file is too big. Keep it under 2 MB.');
  $level=selected_start_level(1,true);$rows=import_read_file($f['tmp_name'],(string)$f['name']);
  $checked=import_check($rows,$u,(int)($_POST['section_id']??0),$level);
  $_SESSION['pupil_import']=['token'=>bin2hex(random_bytes(16)),'file'=>mb_substr(basename((string)$f['name']),0,120),'rows'=>$checked,'teacher'=>(int)$u['id']];unset($_SESSION['pupil_import_done']);
  go('?page=accounts&mode=class&import=preview#import');
 }
 if($action==='import_cancel'){require_role('teacher');unset($_SESSION['pupil_import']);flash('Import cancelled. No accounts were created.');go('?page=accounts&mode=class#import');}
 if($action==='import_confirm'){
  $u=require_role('teacher');$p=$_SESSION['pupil_import']??null;
  if(!$p||!hash_equals($p['token'],(string)($_POST['token']??''))||(int)$p['teacher']!==(int)$u['id'])fail('This import has expired. Upload the class list again.');
  $rows=$p['rows'];$lv=(array)($_POST['lv']??[]);$rc=function_exists('rc_ready')&&rc_ready();   // the starting level the teacher chose for each pupil
  foreach($rows as $i=>&$r)if($r['status']==='ok'&&isset($lv[$i])){$v=(int)$lv[$i];if(($v===0&&$rc)||($v>0&&val('SELECT id FROM bulig_levels WHERE id=?',[$v])))$r['level']=$v;}unset($r);
  import_create($rows,$u,$p['file']);
 }
 if($action==='import_typed'){
  $u=require_role('teacher');$tid=(int)$u['id'];$many=($_POST['sec_mode']??'')==='many';$level=selected_start_level(1,true);
  $mine=[];foreach(teacher_sections($tid) as $x)$mine[(int)$x['id']]=$x;
  $sid=0;$newSec=null;
  if(!$many){if(($_POST['section_id']??'')==='new')$newSec=section_new_input();else{$sid=(int)($_POST['section_id']??0);if(!$sid)fail('Choose the section for this list.');owned_section($sid,$tid);}}
  $t=(array)($_POST['t']??[]);$keys=['last','first','middle','ext','sex','lrn','sec','level','sup'];$n=0;foreach($keys as $k)foreach(array_keys((array)($t[$k]??[])) as $i)$n=max($n,(int)$i+1);
  if($n>IMPORT_MAX_ROWS)fail('Type up to '.IMPORT_MAX_ROWS.' pupils at a time.');
  $codes=[0=>'BULIG',1=>'1',2=>'2A',3=>'2B',4=>'3A',9=>'3B',5=>'4',6=>'5',7=>'6',8=>'7'];
  $typed=[];$list=[];
  for($i=0;$i<$n;$i++){$r=[];foreach($keys as $k)$r[]=mb_substr(trim((string)(((array)($t[$k]??[]))[$i]??'')),0,80);
   if($r[0].$r[1].$r[2].$r[5]===''){$typed[]=array_fill(0,9,'');$list[]=array_fill(0,10,'');continue;}   // only M or F picked: an empty row
   $typed[]=$r;$sec=$newSec?['grade_level'=>$newSec[0],'name'=>$newSec[1]]:($many?($mine[(int)$r[6]]??null):null);$lv=$r[7]===''?$level:(int)$r[7];
   $list[]=[$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$sec['name']??'',$sec?(string)$sec['grade_level']:'',$codes[$lv]??'',$r[8]];}
  if(!array_filter($typed,fn($r)=>implode('',$r)!==''))fail('Type at least one pupil first.');
  $checked=import_check(array_merge([['Last name','First name','Middle name','Extension','Sex','LRN','Section','Grade','Starting level','Reading support']],$list),$u,$sid,$level);
  foreach($checked as &$c){$c['line']--;$c['notes']=array_map(fn($x)=>preg_replace_callback('/line (\d+) in this file/',fn($m)=>'row '.((int)$m[1]-1).' of this list',str_starts_with($x,'Section is missing')?'Choose a section.':$x),$c['notes']);}unset($c);   // row numbers of the list, not of a file
  $bad=array_filter($checked,fn($r)=>$r['status']==='error');
  if($bad){$_SESSION['pupil_typed']=['rows'=>$typed,'notes'=>array_column(array_map(fn($r)=>[$r['line']-1,implode(' ',array_filter($r['notes'],fn($x)=>!str_starts_with($x,'New section')))],$bad),1,0),'section'=>$sid,'level'=>$level,'many'=>$many,'new'=>$newSec];
   flash(count($bad).' '.(count($bad)===1?'row needs':'rows need').' fixing. Nothing was saved yet: fix the rows marked in red, then press Create again.');go('?page=accounts&mode=class&how=type#import');}
  unset($_SESSION['pupil_typed']);import_create($checked,$u,'the typed list');
 }
}

/** Make the accounts for every ready row (an uploaded file or the typed list), then show the done screen. */
function import_create(array $rows,array $u,string $file):never{
 $done=[];db()->beginTransaction();try{
  $made=[];
  foreach($rows as $r){if($r['status']!=='ok')continue;
   $section=$r['section']?owned_section((int)$r['section']['id'],(int)$u['id']):null;
   if(!$section){$key=mb_strtolower($r['new_section']['name']).'|'.$r['new_section']['grade_level'];
    if(!isset($made[$key])){$id=(int)val('SELECT id FROM sections WHERE teacher_id=? AND grade_level=? AND LOWER(name)=LOWER(?)',[$u['id'],$r['new_section']['grade_level'],$r['new_section']['name']]);
     if(!$id){q('INSERT INTO sections(teacher_id,grade_level,name) VALUES(?,?,?)',[$u['id'],$r['new_section']['grade_level'],$r['new_section']['name']]);$id=(int)db()->lastInsertId();}
     $made[$key]=owned_section($id,(int)$u['id']);}
    $section=$made[$key];}
   if($r['lrn']!==''&&val('SELECT pupil_id FROM pupil_details WHERE lrn=?',[$r['lrn']]))continue;
   $public=create_pupil_account($u,$r['name'],$section,(int)$r['level'],[$r['sex'],$r['lrn']?:null],$r['parts']??null);
   if(($r['support']??'standard')!=='standard'&&function_exists('speech_set'))speech_set((int)val('SELECT id FROM users WHERE public_id=?',[$public]),(string)$r['support']);   // v208 Reading support from the list
   $done[]=['id'=>$public,'name'=>$r['name'],'lrn'=>$r['lrn'],'section'=>'Grade '.$section['grade_level'].' · '.$section['name'],'pw'=>$GLOBALS['last_starter_pw']??'12345678'];}
  audit('import_pupils',count($done).' from '.$file);db()->commit();
 }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
 unset($_SESSION['pupil_import']);$_SESSION['pupil_import_done']=$done;$skip=count(array_filter($rows,fn($r)=>$r['status']==='skip'));
 flash(count($done).' pupil account'.(count($done)===1?'':'s').' created.'.($skip?' '.$skip.' already in BULIG '.($skip===1?'was':'were').' left out.':'').' Each pupil has their own starter password: print their sign-in tickets.');go('?page=accounts&mode=class&import=done#import');
}


function import_download(string $what):never{
 require_role('teacher');header('Content-Type: text/csv; charset=utf-8');
 if($what==='template'){header('Content-Disposition: attachment; filename="BULIG-class-list-template.csv"');
  echo "\xEF\xBB\xBF".'Last name,First name,Middle name,Extension,LRN,Sex,Grade,Section,Starting level,Reading support'."\r\n";exit;}
 $done=$_SESSION['pupil_import_done']??[];if(!$done)fail('There is no finished import to download.',404);
 header('Content-Disposition: attachment; filename="BULIG-new-pupil-logins.csv"');$h=fopen('php://output','w');fwrite($h,"\xEF\xBB\xBF");
 fputcsv($h,['Pupil ID','Name','LRN','Section','Starter password'],',','"','\\');foreach($done as $d)fputcsv($h,[$d['id'],$d['name'],$d['lrn']!==''?'="'.$d['lrn'].'"':'',$d['section'],$d['pw']??'12345678'],',','"','\\');exit;
}

function import_card(array $u):void{
 $sections=teacher_sections((int)$u['id']);$p=$_SESSION['pupil_import']??null;$done=$_SESSION['pupil_import_done']??null;$mode=(string)($_GET['import']??'');$how=($_GET['how']??'')==='file'?'file':'type';
 echo '<section class="card import-card" id="import"><div class="section-heading"><div><span class="eyebrow">ADD A WHOLE CLASS AT ONCE</span><h2>Import a class list</h2></div>'.($mode===''&&$how==='file'?'<a class="btn quiet small" href="?page=import_template">'.icon('arrow').'Download template</a>':'').'</div>';
 if($mode==='preview'&&$p){
  $ok=count(array_filter($p['rows'],fn($r)=>$r['status']==='ok'));$skip=count(array_filter($p['rows'],fn($r)=>$r['status']==='skip'));$bad=count(array_filter($p['rows'],fn($r)=>$r['status']==='error'));
  echo '<p class="import-summary"><strong>'.e($p['file']).'</strong> · <span class="pill ok">'.$ok.' ready</span> <span class="pill skip">'.$skip.' already in BULIG</span> <span class="pill bad">'.$bad.' need fixing</span></p>';
  if($bad)echo '<p class="muted">Rows that need fixing will be left out. Fix them in your file and upload again, or import the ready rows now and add the rest later.</p>';
  $rc=function_exists('rc_ready')&&rc_ready();$lvs=array_map('intval',array_column(rows('SELECT id FROM bulig_levels ORDER BY '.level_order_sql('id')),'id'));
  $opts=fn(int $sel)=>($rc?'<option value="0"'.($sel===0?' selected':'').'>Reading check</option>':'').implode('',array_map(fn($id)=>'<option value="'.$id.'"'.($sel===$id?' selected':'').'>'.e(level_label($id)).'</option>',$lvs));
  if($ok)echo '<label class="imp-lvall">'.icon('edit').'Starting level for every pupil<select data-lv-all><option value="">Choose to set all…</option>'.$opts(-1).'</select><small>You can still change any pupil below.</small></label>';
  echo '<div class="tablewrap import-preview"><table><thead><tr><th>Line</th><th>Name</th><th>LRN</th><th>Sex</th><th>Section</th><th>Start</th><th>Check</th></tr></thead><tbody>';
  foreach($p['rows'] as $i=>$r){$sec=$r['section']??$r['new_section'];echo '<tr class="row-'.$r['status'].'"><td>'.$r['line'].'</td><td>'.e($r['name']?:'—').'</td><td>'.e($r['lrn']?:'—').'</td><td>'.e($r['sex']?ucfirst($r['sex']):'—').'</td><td>'.e($sec?'Grade '.$sec['grade_level'].' · '.$sec['name']:'—').'</td><td>'.($r['status']==='ok'?'<select class="imp-lv" name="lv['.$i.']" form="imp-confirm" data-lv aria-label="Starting level for '.e($r['name']).'">'.$opts((int)$r['level']).'</select>':e((int)$r['level']?level_label((int)$r['level']):'Reading check')).'</td><td><span class="pill '.($r['status']==='ok'?'ok':($r['status']==='skip'?'skip':'bad')).'">'.($r['status']==='ok'?'Ready':($r['status']==='skip'?'Skip':'Fix')).'</span>'.($r['notes']?'<small>'.e(implode(' ',$r['notes'])).'</small>':'').'</td></tr>';}
  echo '</tbody></table></div><div class="import-actions">';
  if($ok)echo '<form method="post" id="imp-confirm">'.csrf_field().'<input type="hidden" name="action" value="import_confirm"><input type="hidden" name="token" value="'.e($p['token']).'"><button class="btn primary">'.icon('check').'Create '.$ok.' pupil account'.($ok===1?'':'s').'</button></form>';
  echo '<form method="post">'.csrf_field().'<input type="hidden" name="action" value="import_cancel"><button class="btn secondary">Cancel</button></form></div></section>';return;
 }
 if($mode==='done'&&$done){
  echo '<p class="import-summary"><span class="pill ok">'.count($done).' accounts created</span> Each new pupil has their own starter password. Print their sign-in tickets: one scan of the QR code signs them in.</p><div class="import-actions"><a class="btn primary" href="?page=import_logins">'.icon('arrow').'Download login list (CSV)</a><a class="btn secondary" href="?page=accounts&amp;mode=class#import">Import another list</a></div>';
  echo '<div class="tablewrap import-preview"><table><thead><tr><th>Pupil ID</th><th>Name</th><th>LRN</th><th>Section</th></tr></thead><tbody>';foreach($done as $d)echo '<tr><td><strong>'.e($d['id']).'</strong></td><td>'.e($d['name']).'</td><td>'.e($d['lrn']?:'—').'</td><td>'.e($d['section']).'</td></tr>';echo '</tbody></table></div></section>';return;
 }
 $tab=fn($k,$ic,$t)=>'<a href="?page=accounts&amp;mode=class&amp;how='.$k.'#import"'.($how===$k?' class="on" aria-current="page"':'').'>'.icon($ic).$t.'</a>';
 echo '<nav class="bk-tabs" aria-label="How to add the class">'.$tab('type','edit','Type the list').$tab('file','excel','Upload a file').'</nav>';
 if($how==='type'){echo import_typed_grid($sections).'</section>'.names_script();return;}
 echo '<ol class="import-steps"><li><strong>Have the DepEd SF1 (School Register) from LIS?</strong> Upload it just as it is — BULIG takes the LRN, name, sex, grade and section from it and leaves the rest. Using your own list? Keep a header row with <strong>Name</strong> (or Last name, First name, Middle name, Extension), <strong>LRN</strong>, <strong>Sex</strong> and, if you like, <strong>Grade</strong>, <strong>Section</strong> and <strong>Starting level</strong>.</li><li>Upload the file (.xls, .xlsx or .csv). Nothing is saved yet — you will see every row first.</li><li>Press <strong>Create accounts</strong>, then download the login list to give each pupil their ID.</li></ol>';
 echo '<form method="post" enctype="multipart/form-data" class="formgrid import-form">'.csrf_field().'<input type="hidden" name="action" value="import_preview"><input type="hidden" name="MAX_FILE_SIZE" value="2097152"><label class="import-file">Class list file (SF1 .xls, .xlsx or .csv)<input type="file" name="class_list" accept=".csv,.xlsx,.xls,.txt,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required></label>';
 echo '<label>Section for pupils without one<select name="section_id"><option value="0">Use the Section column (or the SF1 section)</option>';foreach($sections as $s)echo '<option value="'.$s['id'].'">Grade '.$s['grade_level'].' · '.e($s['name']).'</option>';echo '</select></label>'.starting_level_field(function_exists('rc_ready')&&rc_ready()?0:1).'<div class="formend"><small>Up to '.IMPORT_MAX_ROWS.' pupils, 2 MB. Sections not found are added when the file has a Grade column. Pupils already in BULIG (same LRN) are skipped.</small><button class="btn primary">'.icon('arrow').'Check the list</button></div></form></section>';
}

/** "Type the list": one row per pupil. Enter goes to the next pupil; assets/names.js checks each row while typing.
   Rows that need fixing come back here with the server's note (nothing is saved until every row is right). */
function import_typed_grid(array $sections):string{
 $tid=(int)current_user()['id'];$back=$_SESSION['pupil_typed']??null;unset($_SESSION['pupil_typed']);$rows=$back['rows']??[];$notes=$back['notes']??[];$many=!empty($back['many']);
 $sid=(int)($back['section']??($_GET['section']??(count($sections)===1?$sections[0]['id']:0)));$level=(int)($back['level']??(function_exists('rc_ready')&&rc_ready()?0:1));
 $mode=fn($v,$on,$b,$t)=>'<label class="'.($on?'on':'').'"><input type="radio" name="sec_mode" value="'.$v.'"'.($on?' checked':'').' data-bk-mode><i></i><div><b>'.$b.'</b><span>'.$t.'</span></div></label>';
 $h='<form method="post" class="bk-form" data-bk data-mode="'.($many?'many':'one').'">'.csrf_field().'<input type="hidden" name="action" value="import_typed">'
  .'<div class="sx-mode">'.$mode('one',!$many,'All pupils in one section','Choose the section once, for the whole list.').$mode('many',$many,'Pupils in different sections','Choose the section on each row.').'</div>'
  .'<div class="bk-top"><div class="bk-onesec">'.section_select($sections,$sid,$tid).'</div><div class="bk-lvall">'.str_replace(['<label>Starting level<select name="level_id" required>'],['<label>Starting level for everyone<select name="level_id" required data-bk-lvall>'],starting_level_field($level)).'</div></div>'
  .'<p class="sx-hint">Each pupil can start at a different level: change it on that pupil’s row.</p>';
 $h.='<div class="bk-gridwrap"><table class="bk-grid"><thead><tr><th>#</th><th>Last name</th><th>First name</th><th>Middle name</th><th class="c-ext">Ext.</th><th class="c-sex">Sex</th><th class="c-sec">Section</th><th class="c-lv">Starting level</th><th class="c-lrn">LRN (optional)</th><th class="c-sup">Reading support</th><th class="c-st"><span class="sr-only">Check</span></th></tr></thead><tbody data-bk-body>';
 for($i=0,$n=max(10,count($rows));$i<$n;$i++)$h.=import_typed_row($i,$rows[$i]??[],$notes[$i]??'',$sections,$level);
 $h.='</tbody></table></div><template data-bk-tpl>'.import_typed_row(-1,[],'',$sections,$level).'</template>';
 return $h.'<div class="bk-foot"><small>Press <b>Enter</b> for the next pupil. Empty rows are skipped. <span data-bk-count aria-live="polite"></span></small><span class="bk-btns"><button type="button" class="btn secondary" data-bk-more>+ 10 more rows</button><button class="btn primary" data-bk-go>'.icon('check').'<span data-bk-label>Create pupil accounts</span></button></span></div></form>';
}
function import_typed_row(int $i,array $r,string $note,array $sections,int $level):string{
 $n=$i<0?'__':(string)$i;$v=fn($k)=>e((string)($r[$k]??''));$ext=(string)($r[3]??'');$sex=strtoupper((string)($r[4]??''));
 $in=fn($k,$col,$lab,$extra='')=>'<td data-l="'.$lab.'"><input name="t['.$col.']['.$n.']" value="'.$v($k).'" maxlength="60" autocomplete="off" aria-label="'.$lab.', pupil '.($i<0?'':$i+1).'"'.$extra.'></td>';
 $o='<option value="">—</option>';foreach(NAME_EXTS as $x)$o.='<option value="'.$x.'"'.(name_ext_norm($ext)===$x?' selected':'').'>'.$x.'</option>';
 $mf='';foreach(['M'=>'Male','F'=>'Female'] as $k=>$t)$mf.='<label><input type="radio" name="t[sex]['.$n.']" value="'.$k.'"'.(in_array($sex,[$k,strtoupper($t)],true)?' checked':'').' aria-label="'.$t.'"><b>'.$k.'</b></label>';
 return '<tr data-bk-row'.($note!==''?' class="err"':'').'><td data-bk-n>'.($i<0?'':$i+1).'</td>'.$in(0,'last','Last name',$i===0?' placeholder="Type here…"':'').$in(1,'first','First name').$in(2,'middle','Middle name')
  .'<td class="c-ext" data-l="Ext."><select name="t[ext]['.$n.']" aria-label="Extension">'.$o.'</select></td><td class="c-sex" data-l="Sex"><span class="bk-sex">'.$mf.'</span></td>'
  .import_typed_choices($n,$r,$sections,$level).'<td class="c-lrn" data-l="LRN (optional)"><input name="t[lrn]['.$n.']" value="'.$v(5).'" maxlength="14" inputmode="numeric" autocomplete="off" aria-label="LRN"></td>'.import_support_cell($n,(string)($r[8]??'')).'<td class="c-st" data-bk-st>'.($note!==''?'<span class="bad">'.e($note).'</span>':'').'</td></tr>';
}
/** v208 Reading support for a typed row (Standard, Accent-friendly, Speech support). */
function import_support_cell(string $n,string $v):string{$v=function_exists('speech_parse')?speech_parse($v):'standard';$o='';foreach((defined('SPEECH_MODES')?SPEECH_MODES:['standard'=>['Standard','']]) as $k=>[$t])$o.='<option value="'.$k.'"'.($k===$v?' selected':'').'>'.e($t).'</option>';
 return '<td class="c-sup" data-l="Reading support"><select name="t[sup]['.$n.']" aria-label="Reading support">'.$o.'</select></td>';}
/** A row's own Section (when pupils are in different sections) and Starting level. */
function import_typed_choices(string $n,array $r,array $sections,int $level):string{
 $sec=(int)($r[6]??0);$lv=($r[7]??'')===''?$level:(int)$r[7];
 $o='<option value="">Choose</option>';foreach($sections as $s)$o.='<option value="'.$s['id'].'"'.((int)$s['id']===$sec?' selected':'').'>'.e('Gr. '.(int)$s['grade_level'].' · '.$s['name']).'</option>';
 $l=(function_exists('rc_ready')&&rc_ready()?'<option value="0"'.($lv===0?' selected':'').'>BULIG finds it</option>':'');foreach(rows('SELECT id FROM bulig_levels WHERE published=1 ORDER BY '.level_order_sql('id')) as $x)$l.='<option value="'.$x['id'].'"'.((int)$x['id']===$lv?' selected':'').'>'.e(level_label((int)$x['id'])).'</option>';
 return '<td class="c-sec" data-l="Section"><select name="t[sec]['.$n.']" aria-label="Section">'.$o.'</select></td><td class="c-lv" data-l="Starting level"><select name="t[level]['.$n.']" aria-label="Starting level" data-bk-lv'.($lv!==$level?' class="chg" data-own="1"':'').'>'.$l.'</select></td>';
}
