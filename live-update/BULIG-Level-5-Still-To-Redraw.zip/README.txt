BULIG Level 5 - pictures still to redraw (14)

Level 5 - Grade 1 (14)
  13 old stock photos with a "shutterstock" watermark (4 different pictures):
    grandfather: m008-5, m096-1, p008-5, p096-5
    carrots:     m012-3, m058-1, m101-6, p012-3, p058-1
    banana:      m030-2, p030-2
    dictionary:  m067-1, p067-1
  1 picture that arrived broken: p067-2

Grades 2, 3, 4, 5 and 6 are complete: nothing is missing there.

When redrawing: keep each file name exactly the same, keep the same shape
(width and height), and save as .webp. Put them back in the same grade folders.
